import java.io.BufferedReader;

import java.io.FileNotFoundException;

import java.io.FileReader;

import java.io.IOException;

import java.sql.SQLException;
import java.util.List;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class PaymentBO {

	public List<Cheque> getChequeList(String[] fileData)
			throws IOException, ClassNotFoundException, SQLException, InvalidPaymentException {

		Payment p = new Payment(Integer.parseInt(fileData[0]), fileData[1], fileData[2], Integer.parseInt(fileData[3]),
				Double.parseDouble(fileData[4]), fileData[5]);

		Cheque c = new Cheque(Integer.parseInt(fileData[6]), fileData[7], fileData[8], p);

		List<Cheque> chequeList = new ArrayList<Cheque>();

		chequeList.add(c);

		c = null;

		return chequeList;

	}

	public String[] getFileDetails() throws IOException {
		System.out.println(System.getProperty("user.dir"));

		BufferedReader br = br = new BufferedReader(new FileReader("Payment.csv"));
		//BufferedReader br = new BufferedReader(new FileReader("Payment.csv"));

		String s = null;

		String[] lines1 = new String[100];

		int i = 0;

		while ((s = br.readLine()) != null)

		{

			lines1[i] = s;

			i++;

		}

		String[] lines2 = new String[i];

		for (int j = 0; j < i; j++)

		{

			lines2[j] = lines1[j];

		}

		return lines2;

	}

}
