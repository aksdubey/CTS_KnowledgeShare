import java.io.*;

import java.sql.SQLException;

import java.util.List;

import java.sql.Connection;

import java.sql.DriverManager;

import java.sql.PreparedStatement;

import java.sql.ResultSet;

import java.sql.SQLException;

import java.sql.Statement;

import java.util.ArrayList;

import java.util.List;

import java.util.ResourceBundle;

public class Main {

	public static void main(String args[])
			throws IOException, ClassNotFoundException, SQLException, InvalidPaymentException

			, InstantiationException, IllegalAccessException

	{

		PaymentBO paymentBO = new PaymentBO();

		PaymentDAO pd = new PaymentDAO();
		
		String[] details = paymentBO.getFileDetails();

		int n = details.length;

		boolean flag1 = true;

		String[] arr = new String[9];

		List<Cheque> chequeList = new ArrayList<Cheque>();
		
		
		
		System.out.println("Payment and Cheque details :");

		System.out.format("%-2s %-7s %-9s %-4s %-8s %-9s %-8s %-8s\n", "Id", "Customer", "InvoiceNo", "Attempt",
				"Amount", "Status", "Bank", "ChequeNo");

		for (int i = 0; i < details.length; i++)

		{

			arr = details[i].split(",");

			String Inv = arr[2].substring(0, 3);

			String num = arr[2].substring(3, 5);

			if (flag1)

			{

				chequeList = paymentBO.getChequeList(arr);

				pd.insertPaymentDetails(chequeList);

				for (Cheque c : chequeList)

				{

					System.out.format("%-2s %-7s %-9s %-7s %-8s %-9s %-8s %-8s\n", c.getPayment().getId(),
							c.getPayment().getCustomerName(), c.getPayment().getInvoiceNumber(),
							c.getPayment().getAttempt(), c.getPayment().getAmount(), c.getPayment().getStatus(),
							c.getBankName(), c.getChequeNumber());

				}

			}

		}

		

		try {

			
			for (int i = 0; i < details.length; i++)

			{

				arr = details[i].split(",");

				String Inv = arr[2].substring(0, 3);

				String num = arr[2].substring(3, 5);

				String flag = "false";

				char[] ch = num.toCharArray();

				for (char c : ch)

				{

					if (Character.isDigit(c))

					{

						flag = "true";

					}

					else

					{

						flag = "false";

						break;

					}

				}

				if (Inv.equals("INV") && flag.equals("true"))

				{

				}

				else

				{

					flag1 = false;

					throw new InvalidPaymentException("InvalidPaymentException: Invalid invoice number :", arr[2]);

				}

			}

		

		}

		catch (InvalidPaymentException e) {

			System.out.println("Update correct invoice number in file");

		}

	}

}
