public class InvalidPaymentException extends Exception {

	InvalidPaymentException(String invoice, String m)

	{

		super();

		System.out.println(invoice + m);

	}

}
