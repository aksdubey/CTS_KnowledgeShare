import java.sql.*;

import java.util.ArrayList;

import java.util.List;

import java.util.ResourceBundle;

public class PaymentDAO implements IPaymentDAO {

	public void insertPaymentDetails(List<Cheque> chequeList)
			throws SQLException, InstantiationException, IllegalAccessException, ClassNotFoundException {

		DBConnection con = new DBConnection();

		Connection connect = con.getConnection();

		String sql = "insert into payment (id,customer_name,invoice_number,attempt,amount,status) values (?,?,?,?,?,?)";

		PreparedStatement pstmt = connect.prepareStatement(sql);

		for (Cheque c : chequeList)

		{

			pstmt.setInt(1, c.getPayment().getId());

			pstmt.setString(2, c.getPayment().getCustomerName());

			pstmt.setString(3, c.getPayment().getInvoiceNumber());

			pstmt.setInt(4, c.getPayment().getAttempt());

			pstmt.setDouble(5, c.getPayment().getAmount());

			pstmt.setString(6, c.getPayment().getStatus());

		}

		pstmt.executeUpdate();

		String insert1 = "insert into cheque (id,bank_name,cheque_number,payment_id) values (?,?,?,?)";

		PreparedStatement pstmt1 = connect.prepareStatement(insert1);

		for (Cheque c : chequeList)

		{

			pstmt1.setInt(1, c.getChequeId());

			pstmt1.setString(2, c.getBankName());

			pstmt1.setString(3, c.getChequeNumber());

			pstmt1.setInt(4, c.getPayment().getId());

		}

		pstmt1.executeUpdate();

		connect.close();

		pstmt1.close();

		pstmt.close();

	}

	public Payment getPaymentById(Integer paymentId)
			throws SQLException, InstantiationException, IllegalAccessException, ClassNotFoundException {

		DBConnection con = new DBConnection();

		Connection connect = con.getConnection();

		String sql1 = "select * from payment where id=?";

		PreparedStatement pstmt2 = connect.prepareStatement(sql1);

		pstmt2.setInt(1, paymentId);

		ResultSet rs = pstmt2.executeQuery();
		
		
				Payment p = new Payment(rs.getInt("id"), rs.getString("customer_name"), rs.getString("invoice_number"), rs.getInt("attempt"), rs.getDouble("amount"), rs.getString("status"));
		
		
		while (rs.next())

		{

			p.setId(rs.getInt(1));

			p.setCustomerName(rs.getString(2));

			p.setInvoiceNumber(rs.getString(3));

			p.setAttempt(rs.getInt(4));

			p.setAmount(rs.getDouble(5));

			p.setStatus(rs.getString(6));

		}

		connect.close();

		pstmt2.close();

		return p;

	}

}
