package encapsulationAndAccessIDentifiers1;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in = new Scanner(System.in);
		Cargo cargo = new Cargo();
		System.out.println("Enter the cargo details:");
		System.out.println("Enter the name");
		cargo.setName(in.nextLine());
		System.out.println("Enter the description");
		cargo.setDescription(in.nextLine());
		System.out.println("Enter the length");
		cargo.setLength(Double.parseDouble(in.nextLine()));
		System.out.println("Enter the width");
		cargo.setWidth(Double.parseDouble(in.nextLine()));
		
		cargo.displayCargoDetails();
		
		in.close();
	}

}
