package encapsulationAndAccessIDentifiers1;

public class Cargo {

	private String name;
	private String description;
	private Double width;
	private Double length;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Double getWidth() {
		return width;
	}
	public void setWidth(Double width) {
		this.width = width;
	}
	public Double getLength() {
		return length;
	}
	public void setLength(Double length) {
		this.length = length;
	}
	
	public void displayCargoDetails()
	{
		//display the cargo details
		
		/**
		 * The cargo details are:
Name : Car
Description : Four wheeler
Length : 390.5 cm
Width : 160.5 cm
		 */
		
		System.out.println("The cargo details are:");
		System.out.println("Name : " + getName() 
				+ "\nDescription : " + getDescription() 
				+ "\nLength : " + getLength() + " cm" 
				+ "\nWidth : " + getWidth() + " cm");
		
	}
	
	
}
