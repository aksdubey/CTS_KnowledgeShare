package pkgCollectionsLC7;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class Main {
	public static void main(String args[]) throws NumberFormatException, IOException{
		
		// fill the code
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	 	   //fill your code
			List<Integer> listAllItems = new ArrayList<Integer>();
 			List<Integer> listUniqueItems = new ArrayList<Integer>();
			String[] details;
			Map<Integer,Integer> mapCount = new HashMap<Integer,Integer>();
	 	 	System.out.println("Enter the number of shipments");
	 		int No = Integer.parseInt(br.readLine());
	 		System.out.println("Enter shipment details");
	 		for(int i=0; i<No; i++)
	 		{
	 			details = br.readLine().split(",");
	 			listAllItems.add(Integer.parseInt(details[2]));
	 			listAllItems.add(Integer.parseInt(details[3])); 	 			
	 		}
	 		
	 		
	 		for(int i: listAllItems)
	 		{
	 			if(!listUniqueItems.contains(i))
	 				listUniqueItems.add(i);
	 		}
	 		
	 		List<Integer> sortedList = new ArrayList<Integer>();
	 		sortedList.addAll(listUniqueItems);
	 		Collections.sort(sortedList);
	 		
	 		int cnt;
	 		for(int i: sortedList)
	 		{
	 			cnt = 0;
	 			for(int j: listAllItems)
	 			{
	 				if(i==j)
	 				{
	 					cnt++;
	 				}
	 			}
	 			mapCount.put(i, cnt);
	 		}
	 		
	 		System.out.format("%-15s%-15s\n", "Port id","Number of Shipments");
		 	for(Entry<Integer, Integer> eachMapCount: mapCount.entrySet())
		 	{
		 		System.out.format("%-15s%-15s\n", eachMapCount.getKey(), eachMapCount.getValue());		 		
		 	}
	}
}


