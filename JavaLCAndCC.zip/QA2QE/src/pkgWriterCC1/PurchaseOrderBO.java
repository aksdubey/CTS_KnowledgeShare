package pkgWriterCC1;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.List;

public class PurchaseOrderBO {
	
	void  createPurchaseOrder(String customername ,List<Item> items,List<Integer> quantity,String outputfilename) throws IOException
	{
		/*
		 * Create purchase order based on all the selected items and 
		 * and the total amount and write it to a file in the given format.
		 */
		int i=-1;
		double sum = 0.00;
		File file = new File(outputfilename);
		BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file)));
		
		writer.write("Name : " + customername + "\n");
		
		for(Item eachItem: items)
		{
			i++;
			writer.write(eachItem.getName() + "," + eachItem.getPrice() + "," + quantity.get(i) + "," 
					+ (eachItem.getPrice()*quantity.get(i)) + "\n");
			sum += (eachItem.getPrice()*quantity.get(i));
		}
		
		writer.write("Total Amount : " + sum);
		
		
		writer.flush();
		writer.close();
		
	}

}
