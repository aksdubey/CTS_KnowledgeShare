package pkgWriterCC1;

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class Main {
	public static void main(String args[]) throws NumberFormatException, IOException, ParseException
	{
		String[] details, detailsQty;
		List<Item> listShip = new ArrayList<Item>();
		listShip.add(new Item(111, "Laptop", 28000.0));
		listShip.add(new Item(112, "Headset", 900.0));
		listShip.add(new Item(113, "Watch", 3000.0));
		listShip.add(new Item(114, "Fan", 5000.0));
		listShip.add(new Item(211, "Keyboard", 4000.0));
		listShip.add(new Item(212, "Mouse", 300.0));
		listShip.add(new Item(311, "Mike", 2000.0));
		listShip.add(new Item(313, "PC", 25000.0));
		listShip.add(new Item(314, "Inverter", 11000.0));
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the customer name");
		String customername = sc.nextLine();
		System.out.println("Enter the required items");
		details = sc.nextLine().split(",");
		System.out.println("Enter the required quantity");
		detailsQty = sc.nextLine().split(",");
		
		List<Item> listItems = new ArrayList<Item>();
		
		for(int i=0; i<details.length; i++)
		{
			for(Item items: listShip)
			{
				if(Integer.parseInt(details[i]) == items.getId())
				{
					listItems.add(items);
					continue;
				}
			}
		}
		
		List<String> alQty = new ArrayList<String>(Arrays.asList(detailsQty));
		List<Integer> alQtyInt = new ArrayList<Integer>();
		for(String str: alQty)
		{
			alQtyInt.add(Integer.parseInt(str));
		}
		
		
		new PurchaseOrderBO().createPurchaseOrder(customername, listItems, alQtyInt, "output.txt");
		
		sc.close();
}

}
