package pkgStringCC1;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Main {
	public static void main(String args[]){
		
		// fill the code
		String user;
		StringBuilder sb = new StringBuilder();
		Scanner in = new Scanner(System.in);
		System.out.println("Enter the number of username to be validated :");
		int No = Integer.parseInt(in.nextLine());
		System.out.println("Enter the usernames :");
		for(int i=0; i<No; i++)
		{
			user = in.nextLine();
			Pattern pt = Pattern.compile("[^a-zA-Z0-9]");
	        Matcher match= pt.matcher(user);
	        while(match.find())
	        {
	            String s= match.group();
	            user=user.replaceAll("\\"+s, "");
	        }
	        sb.append(user + "\n");
		}
		
		System.out.println("Valid usernames are :\n" + sb);
		
		in.close();
	}
}


