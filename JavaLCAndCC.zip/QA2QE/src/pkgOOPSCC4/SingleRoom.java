package pkgOOPSCC4;

public class SingleRoom extends Room{

	public SingleRoom(Double cost, Integer length, Integer breadth) {
		super(cost, length, breadth);
		// TODO Auto-generated constructor stub
	}

	@Override
	public Double calculateTotalCost(int noOfPersons, int noOfDays) {
		// TODO Auto-generated method stub
		double Rent = getCost()*noOfPersons*noOfDays;
		return Rent;
	}

	@Override
	public Integer calculateArea() {
		// TODO Auto-generated method stub
		return (getLength() * getBreadth());
		
	}
	
	

}
