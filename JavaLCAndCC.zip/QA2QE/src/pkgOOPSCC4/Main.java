package pkgOOPSCC4;

import java.io.*;

public class Main {

    public static void main(String[] args) throws Exception {
        int choice,noOfPerson,noOfDays;
        Boolean roomBoolean = false;
        String roomChoice;
        String lengthBreadth;
        int size=0;
        Double totalCost = null;
        Double totalAmount = 0d;
        Room room;
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Room booking:");
        System.out.println("1. Single room\n2. Double room\n3. Deluxe Room\nEnter your choice:");
        choice = Integer.parseInt(br.readLine());
        System.out.println("Enter the number of person:");
        //fill code here.
        noOfPerson = Integer.parseInt(br.readLine());
        System.out.println("Enter the number of days:");
        //fill code here.
        noOfDays = Integer.parseInt(br.readLine());
        System.out.println("Enter the length x breadth:");
        //fill code here.
        lengthBreadth = br.readLine();
        switch(choice)
        {
            case 1:
            	//single room
                System.out.println("Do you want AC or not (y/n):");
                roomChoice = (br.readLine());
                //fill code here.
                if(roomChoice.equalsIgnoreCase("y"))
                {
                	room = new SingleRoom(600+(600*0.089), Integer.parseInt(lengthBreadth.split("x")[0]), 
	                		Integer.parseInt(lengthBreadth.split("x")[1]));
                }
                else
                {
                	room = new SingleRoom(600+(600*0.058), Integer.parseInt(lengthBreadth.split("x")[0]), 
	                		Integer.parseInt(lengthBreadth.split("x")[1]));
                }
                totalAmount = room.calculateTotalCost(noOfPerson, noOfDays);
                size = room.calculateArea();
                break;
            case 2:
                System.out.println("Do you want extra cot (y/n):");
                roomChoice = (br.readLine());
                if(roomChoice.equalsIgnoreCase("y"))
                {
                	room = new DoubleRoom(1000+(1000*0.064), Integer.parseInt(lengthBreadth.split("x")[0]), 
	                		Integer.parseInt(lengthBreadth.split("x")[1]));
                }
                else
                {
                	room = new DoubleRoom(1000+(1000*0.035), Integer.parseInt(lengthBreadth.split("x")[0]), 
	                		Integer.parseInt(lengthBreadth.split("x")[1]));
                }
                totalAmount = room.calculateTotalCost(noOfPerson, noOfDays);
                size = room.calculateArea();
                //fill code here.
                break;
            case 3:
                System.out.println("Do you want complementary breakfast (y/n):");
                roomChoice = br.readLine();
                if(roomChoice.equalsIgnoreCase("y"))
                {
                	room = new DeluxeRoom(1500+(1500*0.073), Integer.parseInt(lengthBreadth.split("x")[0]), 
	                		Integer.parseInt(lengthBreadth.split("x")[1]));
                }
                else
                {
                	room = new DeluxeRoom(1500+(1500*0.049), Integer.parseInt(lengthBreadth.split("x")[0]), 
	                		Integer.parseInt(lengthBreadth.split("x")[1]));
                }
                totalAmount = room.calculateTotalCost(noOfPerson, noOfDays);
                size = room.calculateArea();
                //fill code here.
                break;
        }
        System.out.println("The total Amount is:"+totalAmount);
        System.out.println("The total area is:"+size+"sq.ft");
    }
    
}
