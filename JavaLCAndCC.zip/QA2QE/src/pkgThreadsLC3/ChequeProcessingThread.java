package pkgThreadsLC3;

import java.util.concurrent.ArrayBlockingQueue;

public class ChequeProcessingThread implements Runnable //fill in your code here
 {
 
	ArrayBlockingQueue<String> queue = new ArrayBlockingQueue<String>(10);
    public ChequeProcessingThread(ArrayBlockingQueue<String> queue) {
		super();
		this.queue = queue;
	}
    
	public ArrayBlockingQueue<String> getQueue() {
		return queue;
	}

	public void setQueue(ArrayBlockingQueue<String> queue) {
		this.queue = queue;
	}
	
    public void run()  {
        //fill in your code here
    	try {
    		String[] details = queue.take().split(",");
			System.out.println("Cheque processing completed for payment id " + details[0]);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
    public void addCheque(String val) {
       //fill in your code here
    	queue.add(val);
    }
}

