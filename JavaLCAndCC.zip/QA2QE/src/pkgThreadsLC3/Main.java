package pkgThreadsLC3;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.concurrent.ArrayBlockingQueue;

public class Main {
    
    public static void main(String args[]) throws IOException, InterruptedException {
        
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        String details = null;
        ArrayBlockingQueue<String> queue = new ArrayBlockingQueue<String>(10);
		CreditCardProcessingThread cc = new CreditCardProcessingThread(queue);
        ChequeProcessingThread ch = new ChequeProcessingThread(queue);
        
        /*Thread ccThread = new Thread(cc);
        ccThread.start();
        
        Thread chThread = new Thread(ch);
        chThread.start();*/
        
        System.out.println("Enter number of payment:");
        int numberOfPayments = Integer.parseInt(reader.readLine());
        
        System.out.println("Enter all the payment details");

        for(int i=0;i<numberOfPayments;i++) {
            //fill in your code here
        	
        	details = reader.readLine();
            
            if(details.split(",")[2].equals("CHEQ"))
            {
                Thread chThread = new Thread(ch);
                chThread.start();
            	ch.addCheque(details);
            }
            else if(details.split(",")[2].equals("CC"))
            {
            	Thread ccThread = new Thread(cc);
                ccThread.start();
            	cc.addCreditCard(details);
            } 
        	
        }

       
        
	// fill in your code here
    }
    
}

