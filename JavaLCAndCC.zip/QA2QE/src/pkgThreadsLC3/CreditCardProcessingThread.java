package pkgThreadsLC3;

import java.util.concurrent.ArrayBlockingQueue;

public class CreditCardProcessingThread implements Runnable //fill in your code here 
{
  // fill in your attributes here
	
	ArrayBlockingQueue<String> queue = new ArrayBlockingQueue<String>(10);
	
	

    public ArrayBlockingQueue<String> getQueue() {
		return queue;
	}

	public void setQueue(ArrayBlockingQueue<String> queue) {
		this.queue = queue;
	}

	public CreditCardProcessingThread(ArrayBlockingQueue<String> queue) {
		super();
		this.queue = queue;
	}

	public void run() {
        
        //fill in your code here
		try {
			String[] details = queue.take().split(",");
			System.out.println("Credit card processing completed for payment id " + details[0]);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
    }
    
    public void addCreditCard(String val) {
        queue.add(val);
    }
    
}

