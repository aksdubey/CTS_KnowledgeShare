package pkgStringLC1;

import java.util.Scanner;

public class Main {
	public static void main(String args[]){
		
		// fill the code
		String[] details = null;
		StringBuilder sb = new StringBuilder();
		Scanner in = new Scanner(System.in);
		System.out.println("Enter the number of shipments:");
		int No = Integer.parseInt(in.nextLine());
		System.out.println("Enter the shipment details:");
		for(int i=0; i<No; i++)
		{
			details = in.nextLine().split(",");
			if(details[1].compareTo(details[2]) == 0)
			{
				sb.append(details[0] + "\n");
			}
		}
		
		System.out.println("Shipments that are arrived on same day:\n" + sb);
		
		in.close();
	}
}


