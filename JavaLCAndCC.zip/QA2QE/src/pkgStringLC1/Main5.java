package pkgStringLC1;

import java.util.Scanner;

public class Main5 {
	
	public static void main(String args[]){
			
		// fill the code
		Scanner in = new Scanner(System.in);
		System.out.println("Enter the username");
		String name = in.nextLine();
		System.out.println("Formatted username\n" + name.toLowerCase());
		in.close();
		
	}

}
