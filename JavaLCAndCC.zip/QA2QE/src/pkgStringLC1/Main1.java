package pkgStringLC1;

import java.util.Scanner;

public class Main1 {
	public static void main(String args[]){
		
		// fill the code
		int startPos = 0, endPos, len;
		String temp;
		Scanner in = new Scanner(System.in);
		System.out.println("Enter the xml input");
		String xml = in.nextLine();
		System.out.format("%-15s %-15s\n","Tag Name","Length");
		for(int i=0; i<xml.length(); i++)
		{
			if(xml.charAt(i) == '{')
			{
				startPos = i;
			}
			if(xml.charAt(i) == '}')
			{
				endPos = i;
				temp = xml.substring(startPos+1, endPos);
				len = temp.length();
				if(!temp.contains("/"))
					System.out.format("%-15s %-15s\n",temp,len);
				startPos = i;
			}
			if((xml.charAt(i) == '{') && (xml.charAt(i+1) == '/'))
			{
				continue;
			}
		}
		
		in.close();
			
	}
}


