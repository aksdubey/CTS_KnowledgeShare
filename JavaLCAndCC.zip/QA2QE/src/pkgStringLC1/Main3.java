package pkgStringLC1;

import java.util.Scanner;

public class Main3 {
	public static void main(String args[]){
		
		// fill the code
		Scanner in = new Scanner(System.in);
		System.out.println("Enter the document 1 content:");
		String doc1 = in.nextLine();
		System.out.println("Enter the document 2 content:");
		String doc2 = in.nextLine();
		if(doc1.equals(doc2))
		{
			System.out.println("Green");
		}
		else if(doc1.replace(" ", "").equals(doc2) || doc2.replace(" ", "").equals(doc1))
		{
			System.out.println("Orange");
		}
		else if(doc1.equalsIgnoreCase(doc2))
		{
			System.out.println("Blue");
		}
		else
		{
			System.out.println("Red");
		}
		
		in.close();
	}
}


