package pkgStringLC1;

import java.util.Scanner;

public class Main4 {

	public static void main(String args[]){
			
		// fill the code		
		String temp;
		boolean blnValid = false;
		Scanner in = new Scanner(System.in);
		System.out.println("Enter the email id");
		String email = in.nextLine();
		for(int i=0; i<email.length(); i++)
		{
			if(email.charAt(i) == '.')
			{
				temp = email.substring(i+1, email.length());
				//System.out.println(email.substring(i+1, email.length()));
				if(temp.equals("com") || temp.equals("net") || temp.equals("biz") || temp.equals("org"))
				{
					blnValid = true;
					break;
				}
			}
		}
		
		if(blnValid)
		{
			System.out.println("Valid domain");
		}
		else
		{
			System.out.println("Not a valid domain");
		}
		
		in.close();
	}
}
