package pkgStringLC1;

import java.util.Scanner;

public class Main2 {
	public static void main(String args[]){
		
		// fill the code
		Scanner in = new Scanner(System.in);
		System.out.println("Enter the file content:");
		String content = in.nextLine();
		System.out.println("Enter the virus keyword:");
		String virus = in.nextLine();
		if(content.contains(virus.trim()))
		{
			System.out.println("Virus " + virus.trim() + " is present");
		}
		else
		{
			System.out.println("Virus " + virus.trim() + " is not present");
		}
		
		in.close();
	}
}


