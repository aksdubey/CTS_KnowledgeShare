package pkgStringLC1;

import java.util.Scanner;

public class Main6 {
	
	public static void main(String args[]){
			
		// fill the code
		
		Scanner in = new Scanner(System.in);
		System.out.println("Enter the generated booking id");
		String id = in.nextLine();
		
		if(id.matches(".*[a-zA-Z]+.*"))
		{
			System.out.println("Generated booking id is not valid");
		}
		else
		{
			System.out.println("Generated booking id is valid");
		}
		
		in.close();
	}

}
