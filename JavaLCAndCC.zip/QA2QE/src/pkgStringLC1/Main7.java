package pkgStringLC1;

import java.util.Scanner;

public class Main7 {
	
	public static void main(String args[]){
			
		// fill the code
		int len;
		String temp;
		Scanner in = new Scanner(System.in);
		System.out.println("Enter the invoice code");
		String str = in.nextLine();
		str = str.replace("CU", "CUR").replace("AT", "AGT").replace("CY", "CMY");
		
		temp = str.substring(3, str.length());
		len = temp.length();
		
		StringBuilder sb = new StringBuilder(temp);
		for(int i=1; i<=(5-len); i++)
		{
			sb.insert(0, "0");
		}
		
		System.out.println("Formated Code :\n" + str.substring(0, 3) + sb);
		
		in.close();
	}
}
