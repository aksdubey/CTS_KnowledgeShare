package pkgThreadsCC2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;



public class Main {
    
    public static void main(String args[]) throws IOException, InterruptedException {
        
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Enter number of notification:");
        int numberOfMsg = Integer.parseInt(reader.readLine());
        List<String> notification = new ArrayList<String>();
        for(int i=0;i<numberOfMsg;i++) {
            
            String line = reader.readLine();
            notification.add(line);
        }
        
        System.out.println("Enter number of threads:");
        int numberOfThreads = Integer.parseInt(reader.readLine());
        
        Thread[] threads = new Thread[numberOfThreads];
        
        NotificationThread[] nt = new NotificationThread[numberOfThreads];
        int eachThreadCatersTo = notification.size()/numberOfThreads;
        int start = 0, end = start+eachThreadCatersTo;
       
        for(int i=0; i<numberOfThreads; i++)
        {
        	/*
        	 * 2 = 0,2----2,4----4,6----6,8-----8,10
        	 * 5 = 0,5----5,10
        	 */
        	nt[i] = new NotificationThread(notification.subList(start, end));
        	threads[i] = new Thread(nt[i]);
        	
        	threads[i].start();
        	threads[i].join();
        	
        	start = end;
        	end = end+eachThreadCatersTo;
        }
        
        /*for(int i=0; i<numberOfThreads; i++)
        {
        	threads[i].join();
        }*/
       
        //fill your code here!!!
    }

}

