package pkgThreadsCC2;

import java.util.List;

public class NotificationThread implements Runnable//fill your code here!!!
{
//fill your attributes here!!!
	private List<String> notification;
	
    public NotificationThread() {
	super();
}

	public NotificationThread(List<String> notification) {
	super();
	this.notification = notification;
}

	public void run() {
        
        //fill your code here!!!
		String[] details;
		for(String str: this.notification)
		{
			details = str.split(",");
			NotificationManager noti = NotificationManager.getInstance();
			noti.sendMessage(details[0], Integer.parseInt(details[1]));
		}
    }
    
    public void setNotification(List<String> notification) {
        this.notification = notification;
    }
    
}
