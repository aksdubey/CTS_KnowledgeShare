package rolesWithMaxPrivileges;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String name, description, privilegeName;
		Scanner in = new Scanner(System.in);
		
		System.out.println("Enter number of role :");
		int No = Integer.parseInt(in.nextLine());
		Role[] role= new Role[No];
		
		for(int i=0; i<No;i++)
		{
			System.out.println("Enter the role " + (i+1) + " details :");
			System.out.println("Enter role name :");
			name = in.nextLine();
			System.out.println("Enter description :");
			description = in.nextLine();
			System.out.println("Enter the privileges :");
			privilegeName = in.nextLine();
			String[] access = privilegeName.split(",");
			Privilege[] privilege = new Privilege[access.length];
			for(int j=0; j<access.length; j++)
			{
				privilege[j] = new Privilege(access[j]);
			}
			role[i] = new Role(name, description, privilege);
		}
		
		RoleBO roleBO = new RoleBO();
		System.out.println("Role names which has more number of privileges :");
		roleBO.display(role);
		
		
		in.close();
	}

}
