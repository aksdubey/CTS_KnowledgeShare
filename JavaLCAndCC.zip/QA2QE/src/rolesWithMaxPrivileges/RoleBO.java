package rolesWithMaxPrivileges;

import java.util.Arrays;

public class RoleBO {
	
	void display(Role[] role)
	{
		String temp = "";
		int max=0, privLength, roleLength;;
		roleLength = role.length;
		
		for(int i=0; i<roleLength; i++)
		{
			privLength = role[i].getPrivilege().length;
			if(max <= privLength)
			{
				max = privLength;
			}
		}
		
		for(int i=0; i<role.length; i++)
		{
			if(role[i].getPrivilege().length == max)
			{
				temp = temp + role[i].getName() + ",";
			}
		}
		
		String[] tempArray = temp.split(",");
		
		Arrays.sort(tempArray);
				
		for(int i=0; i<tempArray.length; i++)
		{
			System.out.println(tempArray[i]);
		}
	}

}
