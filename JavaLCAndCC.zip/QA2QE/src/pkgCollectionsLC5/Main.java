package pkgCollectionsLC5;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;




public class Main {
    
    public static void main(String args[]) throws IOException{
    //fill your code 
    	BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
 	   //fill your code
 	 	List<ShipmentEntity> list = new ArrayList<ShipmentEntity>();
 	 	String[] details = null;
 	 	String choice;
 	 	System.out.println("Enter the shipment entity details");
 	 	do{
 	 		//No++;
 		 	details = br.readLine().split(",");
 	 		list.add(new ShipmentEntity(Integer.parseInt(details[0]), details[1], Integer.parseInt(details[2])));
 	 		System.out.println("Do you want to continue [yes/no]");
 	 		choice = br.readLine(); 
 	 	}
 	 	while(choice.equals("yes"));
 	 	
 	 	
 	 	//Sort
 	 	Collections.sort(list);
 	 	
 	 	System.out.println("After sorting the shipment entity details");
 	 	System.out.format("%-15s %-15s %-15s","Id","Name","Number");
	 	System.out.println();
 	 	for(ShipmentEntity s: list)
 	 	{
 	 		System.out.println(s.toString());
 	 	}
 	 
 	 	
 	 	//accept search value
 	 	System.out.println("Enter the shipment entity details to be searched");
 	 	String[] search = br.readLine().split(",");
 	 	ShipmentEntity shipmentSearch = 
 	 			new ShipmentEntity(Integer.parseInt(search[0]), search[1], Integer.parseInt(search[2]));
 	 	
 	 	//search
 	 	int index = Collections.binarySearch(list, shipmentSearch);
 	 	System.out.println("Shipment entity found in index : " + index);
 	 	
    }
    
}

