package pkgCollectionsLC5;




public class ShipmentEntity implements Comparable<ShipmentEntity>/*fill in the blanks */ {
    
    Integer id;
    String name;
    Integer bookingNumber;

    public ShipmentEntity(Integer id, String name, Integer bookingNumber) {
        this.id = id;
        this.name = name;
        this.bookingNumber = bookingNumber;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getBookingNumber() {
        return bookingNumber;
    }

    public void setBookingNumber(Integer bookingNumber) {
        this.bookingNumber = bookingNumber;
    }

  //fill your code
    public String toString()
    {
 	   return String.format("%-15s %-15s %-15s",getId(),getName(),getBookingNumber());
    }

	@Override
	public int compareTo(ShipmentEntity arg0) {
		// TODO Auto-generated method stub
		if(this.getBookingNumber().compareTo(arg0.getBookingNumber()) < 0)
		{
			return -1;
		}
		else if(this.getBookingNumber().compareTo(arg0.getBookingNumber()) > 0)
		{
			return 1;
		}
	
		return 0;
	}
    
}

