package pkgOOPSLC5;

public class Truck extends GroundTransport{
	
	private int sizeOfContainer;

	public int getSizeOfContainer() {
		return sizeOfContainer;
	}

	public void setSizeOfContainer(int sizeOfContainer) {
		this.sizeOfContainer = sizeOfContainer;
	}

	public Truck(int id, String customerName, String arrivalPort,
			String departurePort, float weight, int sizeOfContainer,
			String capacity) {
		super(id, customerName, arrivalPort, departurePort, weight, capacity);
		this.sizeOfContainer = sizeOfContainer;
	}
	
	@Override
	void displayDetails()
	{
		//System.out.format("%-15s %-15s %-15s %-15s%-15s%-20s%-15s","Id","Customer name","Arrival port","Departure port","Weight","Size of container","capacity");
		System.out.format("%-15s %-15s %-15s %-15s%-15s%-20s%-15s",getId(),getCustomerName(),
				getArrivalPort(),getDeparturePort(),getWeight(),getSizeOfContainer(),getCapacity());
	}
	
	
	

}
