package pkgOOPSLC5;

public class Ferries extends WaterTransport{
	
	private String agentName;

	public String getAgentName() {
		return agentName;
	}

	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}

	public Ferries(int id, String customerName, String arrivalPort,
			String departurePort, float weight, String agentName,
			String capacity) {
		super(id, customerName, arrivalPort, departurePort, weight, capacity);
		this.agentName = agentName;
	}
	
	@Override
	void displayDetails()
	{
		System.out.format("%-15s %-15s %-15s %-15s%-15s%-20s%-15s",getId(),getCustomerName(),
				getArrivalPort(),getDeparturePort(),getWeight(),agentName,getCapacity());
	}
	
	

}
