package pkgOOPSLC5;

public class ContainerShip extends WaterTransport {

	private String companyName;

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public ContainerShip(int id, String customerName, String arrivalPort,
			String departurePort, float weight, String companyName, 
			String capacity) {
		super(id, customerName, arrivalPort, departurePort, weight, capacity);
		this.companyName = companyName;
	}
	
	@Override
	void displayDetails()
	{
		//System.out.format("%-15s %-15s %-15s %-15s%-15s%-20s%-15s","Id","Customer name","Arrival port","Departure port","Weight","Company name","Capacity");
		System.out.format("%-15s %-15s %-15s %-15s%-15s%-20s%-15s",getId(),getCustomerName(),
				getArrivalPort(),getDeparturePort(),getWeight(),getCompanyName(),getCapacity());
	}
	
	
}
