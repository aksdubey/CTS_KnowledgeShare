package pkgOOPSLC5;

public class Rail extends GroundTransport{
	
	private int numberOfContainer;

	public int getNumberOfContainer() {
		return numberOfContainer;
	}

	public void setNumberOfContainer(int numberOfContainer) {
		this.numberOfContainer = numberOfContainer;
	}

	public Rail(int id, String customerName, String arrivalPort,
			String departurePort, float weight, int numberOfContainer, 
			String capacity) {
		super(id, customerName, arrivalPort, departurePort, weight, capacity);
		this.numberOfContainer = numberOfContainer;
	}
	
	@Override
	void displayDetails()
	{
		//System.out.format("%-15s %-15s %-15s %-15s%-15s%-20s%-15s","Id","Customer name","Arrival port","Departure port","Weight","Number of container","Capacity");
		System.out.format("%-15s %-15s %-15s %-15s%-15s%-20s%-15s",getId(),getCustomerName(),
				getArrivalPort(),getDeparturePort(),getWeight(),getNumberOfContainer(),getCapacity());
	}
	
	

}
