package pkgQA2QE;

import java.util.Arrays;
import java.util.Scanner;

public class UniqueItems {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int tempCount = 0, minCount = 1, maxCount = 1;
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the number of items");
        int No = scanner.nextInt();
        scanner.nextLine();
        String[] Items = new String[No];
        String[] UniqueItems = new String[No];
        String[] UniqueMaxItems = new String[No];
        String[] UniqueMinItems = new String[No];
        int[] ItemsCount = new int[No];
        System.out.println("Enter the items");
        
        for(int i=0; i<No; i++)
        {
        	Items[i] = scanner.nextLine();
        }
        
        for(int i=0; i<No; i++)
        {
        	tempCount = 0;
        	for(int j=0; j<No; j++)
        	{
        		if(Items[i].equalsIgnoreCase(Items[j]))
        		{
        			tempCount++;
        		}
        	}
        	ItemsCount[i] = tempCount;
        }
        
        for(int i=0; i<No; i++)
        {
        	System.out.println(Items[i] + "....." + ItemsCount[i]);
        }
        
        for(int i=0; i<No; i++)
        {
        	if(!Arrays.asList(UniqueItems).contains(Items[i]))
        	{
        		UniqueItems[i]=Items[i];
        	}
        }
        
        System.out.println("The unique items are");
        for(int i = 0; i<No; i++)
        {
        	if(UniqueItems[i] != null)
        	{
        		System.out.println(UniqueItems[i]);
        	}
        }
                
        for(int i=0; i<No; i++)
        {
        	if(minCount > ItemsCount[i])
        	{
        		minCount = ItemsCount[i];
        	}
        	if(maxCount < ItemsCount[i])
        	{
        		maxCount = ItemsCount[i];
        	}
        }
        /*System.out.println("min Count: " + minCount);
        System.out.println("max Count: " + maxCount);*/
        
        System.out.println("The maximum purchased item(s) are");
        for(int i=0; i<No; i++)
        {
        	if(ItemsCount[i]==maxCount)
        	{
        		if(!Arrays.asList(UniqueMaxItems).contains(Items[i]))
        		{
        			UniqueMaxItems[i]=Items[i];
        			System.out.println(Items[i]);
        		}
        	}
        }
        
        System.out.println("The minimum purchased item(s) are");
        for(int i=0; i<No; i++)
        {
        	if(ItemsCount[i]==minCount)
        	{        		
        		if(!Arrays.asList(UniqueMinItems).contains(Items[i]))
        		{
        			UniqueMinItems[i]=Items[i];
        			System.out.println(Items[i]);
        		}
        	}
        }
        
        
        
        /*
         * 
watch
laptop
iphone
watch
car
headset
laptop
watch
shoe
mobile
         * The unique items are 
         * watch
         * laptop
         * iphone
         * car
         * headset
         * shoe
         * mobile
         * The maximum purchased item(s) are
         * watch
         * The minimum purchased item(s) are 
         * iphone
         * car
         * headset
         * shoe
         * mobile
         *  
         */
        
        
        scanner.close();
	}

}
