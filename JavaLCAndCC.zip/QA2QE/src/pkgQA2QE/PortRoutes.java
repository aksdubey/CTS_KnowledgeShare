package pkgQA2QE;

import java.util.Scanner;

public class PortRoutes {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String temp;
    	Scanner scanner = new Scanner(System.in);
		//System.out.println("Enter the number of ports");
        int No = scanner.nextInt();
        scanner.nextLine();
//        System.out.println("No: " + No);
        String[][] elements = new String[No][No];
        //System.out.println("Enter the elements");
        
        for(int i=0; i<No; i++)
        {
        	temp = scanner.nextLine();
        	//1 0 1
        	temp = temp.replace(" ", "");
        	//101
        	for(int j=0;j<No; j++)
        	{
	        	//System.out.println("temp: " + temp);	        	
	        	//System.out.println("temp: " + temp);
	        	elements[i][j] = temp.substring(j, (j+1));
	        	//System.out.println(elements[i][0] + ".." + elements[i][1]);
        	}
        }
        
        /*for(int k = 0; k<No; k++)
        {
        	for(int l = 0; l<No; l++)
        	{
        		System.out.print(elements[k][l]);        		
        	}
        	System.out.println();
        }*/

        System.out.println("Enter two port numbers A and B :");
        int No1 = scanner.nextInt();
        int No2 = scanner.nextInt();

        if(elements[No1-1][No2-1].equals("1"))
        {
        	System.out.println("There is a route");
        }
        else
        {
        	System.out.println("There is no route");
        }
        
        scanner.close();
        
	}

}
