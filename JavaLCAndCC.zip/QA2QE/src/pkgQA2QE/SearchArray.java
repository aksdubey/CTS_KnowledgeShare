package pkgQA2QE;

import java.util.Scanner;

public class SearchArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//System.out.println("Enter number of ports :");
		String nameToSearch;
		boolean blnFound = false;
        Scanner scanner = new Scanner(System.in);
        int No = scanner.nextInt();
        scanner.nextLine();
        String[] names = new String[No];
        //System.out.println("Enter port details :");
        
        for(int i=0; i<No; i++)
        {
        	names[i] = scanner.nextLine();
        }
        
        System.out.println("Enter the name you want to search");
        
        nameToSearch = scanner.nextLine();
        for(String str: names)
        {
        	if(str.equalsIgnoreCase(nameToSearch))
        	{
        		blnFound = true;
        		break;
        	}
        }
        if(blnFound)
        {
        	System.out.println(nameToSearch + " found!");
        }
        else
        {
        	System.out.println(nameToSearch + " not found");
        }
        
        scanner.close();

	}

}
