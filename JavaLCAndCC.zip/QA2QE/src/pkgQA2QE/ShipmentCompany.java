package pkgQA2QE;

import java.util.Scanner;

public class ShipmentCompany {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the number of cargo");
        int NoCargo = scanner.nextInt();
        scanner.nextLine();
        String[] cargoIDs = new String[NoCargo];
        System.out.println("Enter the cargo id");
        
        for(int i=0; i<NoCargo; i++)
        {
        	cargoIDs[i] = scanner.nextLine();
        }
        
        System.out.println("Enter the number of shipment");
        int NoShipment = scanner.nextInt();
        scanner.nextLine();
        String[] shipmentNames = new String[NoShipment];
        
        System.out.println("Enter the shipment name");
        
        for(int i=0; i<NoShipment; i++)
        {
        	shipmentNames[i] = scanner.nextLine();
        }
        
        System.out.println("Enter the cargo id");
        String Cargo = scanner.nextLine();
        
        for(int i=0; i<cargoIDs.length; i++)
        {
        	if(cargoIDs[i].equalsIgnoreCase(Cargo))
        	{        		
        		if(i>=shipmentNames.length)
        		{
        			System.out.println("Yet to be shipped");
        		}
        		else
        		{
        			System.out.println(shipmentNames[i]);
        		}
        	}
        }
        
        scanner.close();
	}

}
