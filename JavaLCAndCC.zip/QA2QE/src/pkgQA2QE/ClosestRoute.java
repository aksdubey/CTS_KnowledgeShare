package pkgQA2QE;

import java.util.Scanner;

public class ClosestRoute {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String temp;
		int tempPort1, tempPort2, closerPort2 = 0;
    	Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the number of ports");
        int No = scanner.nextInt();
        scanner.nextLine();
//        System.out.println("No: " + No);
        String[][] elements = new String[No][No];
		System.out.println("Enter the distance between all ports :");
        
        for(int i=0; i<No; i++)
        {
        	temp = scanner.nextLine();
        	//1 0 1
        	temp = temp.replace(" ", "");
        	//101
        	for(int j=0;j<No; j++)
        	{
	        	//System.out.println("temp: " + temp);	        	
	        	//System.out.println("temp: " + temp);
	        	elements[i][j] = temp.substring(j, (j+1));
	        	//System.out.println(elements[i][0] + ".." + elements[i][1]);
        	}
        }
        	
    	/*for(int k = 0; k<No; k++)
        {
        	for(int l = 0; l<No; l++)
        	{
        		System.out.print(elements[k][l]);        		
        	}
        	System.out.println();
        }*/
        for(int k = 0; k<No; k++)
        {
        	tempPort1 = Integer.parseInt(elements[k][0]);
        	closerPort2 = 0;
        	for(int l = 0; l<No; l++)
        	{
        		tempPort2 = Integer.parseInt(elements[k][l]);
        		if(tempPort2 != 0)
        		{
	        		if((tempPort1 > tempPort2) || (tempPort1 == 0))
	        		{
	        			tempPort1 = tempPort2;
	        			closerPort2 = l;
	        		}
        		}
        	}
        	if(tempPort1==0)
    		{
    			System.out.println("No ports are closer to port " + (k+1));
    		}
    		else
    		{
    			System.out.println("Port " + (k+1) + " is closer to port " + (closerPort2+1));
    		}
        	//System.out.println();
        }
        
        scanner.close();
	}

}
