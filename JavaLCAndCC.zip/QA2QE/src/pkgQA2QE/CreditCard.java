package pkgQA2QE;

import java.util.Scanner;

public class CreditCard {
	public static void main(String[] args) {
		// TODO Auto-generated method stub			
		int Cnt = 0, tempCount;
		
		Scanner scanner = new Scanner(System.in);		
		//System.out.println("Enter the number of purchase");
        int No = scanner.nextInt();
        scanner.nextLine();
        
        String[] TransactionID = new String[No];
        int[] ItemsCount = new int[No];
        for(int i=0; i<No; i++)
        {
        	TransactionID[i] = scanner.nextLine();
        	//scanner.nextLine();
        	//scanner.nextLine();
        }
        
        
        for(int i=0; i<No; i++)
        {
        	tempCount = 0;
        	for(int j=0; j<No; j++)
        	{
        		if(TransactionID[i].equals(TransactionID[j]))
        		{
        			tempCount++;
        		}
        	}
        	ItemsCount[i] = tempCount;
        }
        
        for(int i=0; i<No; i++)
        {
        	if(ItemsCount[i] == 1)
        	{
        		Cnt++;
        	}
        }
        
        /*for(int i=0; i<No; i++)
        {
        	if(!Arrays.asList(UniqueItems).contains(TransactionID[i]))
        	{
        		UniqueItems[i]=TransactionID[i];
        	}
        }*/
        
        
        
        System.out.println(Cnt);
        
        scanner.close();
	}

}
