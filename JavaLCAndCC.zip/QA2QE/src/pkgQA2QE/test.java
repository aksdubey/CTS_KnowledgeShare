package pkgQA2QE;

import java.util.Scanner;

public class test {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/*doScannerTest ("Y~2011~GT~Nepal~Ganesh~Tiwari~N", "~");
		doScannerTest("Y|2011|GT|Nepal|Ganeshd de|Tiwari|N", "\\|");*/

		String str = "a c";
		System.out.println(str.substring(0, 1));
		System.out.println(str.substring(str.length()-1, 3));
        
        
        /*InputStreamReader r= new InputStreamReader(System.in);
        BufferedReader br = new BufferedReader(r);*/
        
       	
	}
	
	private static void doScannerTest(String recordLine, String delim) {
	    Scanner lineScanner = new Scanner(recordLine);
	    lineScanner.useDelimiter(delim);
	    while (lineScanner.hasNext()) {
	        System.out.println(lineScanner.next());
	    }
	    
	    
	    lineScanner.close();
	}
	
	

}
