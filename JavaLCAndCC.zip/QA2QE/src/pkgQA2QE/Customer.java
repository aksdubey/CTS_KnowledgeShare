package pkgQA2QE;

import java.util.Arrays;
import java.util.Scanner;

public class Customer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub		
		double Total = 0;
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the number of purchase");
        int No = scanner.nextInt();
        //scanner.nextLine();
        int[] CustomerId = new int[No];
        String[] UniqueCustomerIDs = new String[No];
        double[] TotalAmount = new double[No];
        double[] UniqueTotalAmt = new double[No];
        /*String[] UniqueItems = new String[No];
        String[] UniqueMaxItems = new String[No];
        String[] UniqueMinItems = new String[No];*/
        //int[] ItemsCount = new int[No];
        System.out.println("Enter the purchase details");
        
        for(int i=0; i<No; i++)
        {
        	CustomerId[i] = scanner.nextInt();
        	//scanner.nextLine();
        	TotalAmount[i] = scanner.nextDouble();
        	//scanner.nextLine();
        }
        
        for(int i=0; i<No; i++)
        {
        	Total = 0;
        	for(int j=0; j<No; j++)
        	{
        		if(CustomerId[i] == CustomerId[j])
        		{
        			Total = Total + TotalAmount[j];
        		}
        	}
        	TotalAmount[i] = Total;
        }
        
        for(int i=0; i<No; i++)
        {
        	if(!Arrays.asList(UniqueCustomerIDs).contains(String.valueOf(CustomerId[i])))
        	{
        		UniqueCustomerIDs[i]=String.valueOf(CustomerId[i]);
        		UniqueTotalAmt[i]=TotalAmount[i];
        	}
        }
        
        
        
        System.out.printf("%-15s %-15s","Customer Id","Total Amount");
        for(int i=0; i<No; i++)
        {
        	if(UniqueCustomerIDs[i] != null)
        	{
        		System.out.println();
        		System.out.printf("%-15s %-15s",UniqueCustomerIDs[i],UniqueTotalAmt[i]);
        	}
        }
        
        scanner.close();
        /**
         * 
1
10.0
1
20.0
1
30.0
1
2.0
1
8.0 
         */
	}

}
