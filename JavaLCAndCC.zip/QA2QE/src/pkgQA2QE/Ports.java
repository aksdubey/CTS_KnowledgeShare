package pkgQA2QE;
import java.util.Scanner;


public class Ports {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// fill the code
		boolean blnOneModeAvailable = false,
		        blnMoreModeAvailable = false;
		        String[] eachNameDetails;
		        System.out.println("Enter number of ports :");
		        Scanner scanner = new Scanner(System.in);
		        int No = scanner.nextInt();
		        scanner.nextLine();
		        String[] names = new String[No];
		        String[] OneModeID = new String[No];
		        String[] OneModeName = new String[No];
		        String[] MoreModeID = new String[No];
		        String[] MoreModeName = new String[No];
		        System.out.println("Enter port details :");
		        
		        
		        /*InputStreamReader r= new InputStreamReader(System.in);
		        BufferedReader br = new BufferedReader(r);*/
		        
		        for(int i=0; i<No; i++)
		        {
		            //try{
		                names[i] = scanner.nextLine();
		            /*}
		            catch(IOException e)
		            {
		                e.printStackTrace();
		            }*/
		        }
		        
		        for(int i=0; i< No; i++)
		        {
		            eachNameDetails= names[i].split("\\|");
		            if((eachNameDetails[2].equals("1") && eachNameDetails[3].equals("1") && eachNameDetails[4].equals("0"))
		            || (eachNameDetails[2].equals("1") && eachNameDetails[3].equals("0") && eachNameDetails[4].equals("1"))
		            || (eachNameDetails[2].equals("0") && eachNameDetails[3].equals("1") && eachNameDetails[4].equals("1"))
		            ||(eachNameDetails[2].equals("1") && eachNameDetails[3].equals("1") && eachNameDetails[4].equals("1")))
		            {
		                MoreModeID[i] = eachNameDetails[0];
		                MoreModeName[i] = eachNameDetails[1];
		                blnMoreModeAvailable = true;
		            }
		            else if(eachNameDetails[2].equals("1") || eachNameDetails[3].equals("1") || eachNameDetails[4].equals("1"))
		            {
		                OneModeID[i] = eachNameDetails[0];
		                OneModeName[i] = eachNameDetails[1];
		                blnOneModeAvailable = true;
		            }
		            	
		        }
		        
		        System.out.println("One mode of transportation :");
		        if(!blnOneModeAvailable)
		        {
		            System.out.println("No such transportation available");
		        }
		        else
		        {
		        	System.out.printf("%-5s%s\n","Id","Name");        	
		            for(int i=0; i<No; i++)
		            {
		                if(OneModeID[i]!=null)
		                {
		                    System.out.format("%-5s%s\n",OneModeID[i],OneModeName[i]); 
		                }
		            }
		        }
		        
		        System.out.println("More than one mode of transportation :");
		        if(!blnMoreModeAvailable)
		        {
		            System.out.println("No such transportation available");
		        }
		        else
		        {
		            System.out.format("%-5s%s\n","Id","Name");
		            for(int i=0; i<No; i++)
		            {
		                if(MoreModeID[i] != null)
		                {
		                    System.out.format("%-5s%s\n",MoreModeID[i],MoreModeName[i]); 
		                }
		            }
		            
		        }
		        scanner.close();
	}

}
