package pkgTest1;

import java.util.ArrayList;
import java.util.List;

import pkgThreadsCC1.Item;

class MyThread extends Thread
{
	private String itemName;
	private List<Item> itemList = new ArrayList<Item>();  
	private List<Item> filteredItems = new ArrayList<Item>();
    
	/*public SearchProviderThread(String name) {
        super(name);
    }*/
	
    public MyThread(String itemName,List<Item> itemList) {
        this.itemName = itemName;
        this.itemList = itemList;
        //System.out.println(this.itemName.toString()+ ", " + this.itemList.toString());
    }
	
 public void run()
 {
	 System.out.println("concurrent thread started running..");
	 for(Item i: itemList)
 	{
 		if(i.getName().equalsIgnoreCase(itemName))
 		{
 			filteredItems.add(i);
 		}
 	}
	 System.out.println("filteredItems size: " + filteredItems.size());
 }
 
 public List<Item> getFilteredItems() {
     return filteredItems;
 }

 public void setFilteredItems(List<Item> filteredItems) {
     this.filteredItems = filteredItems;
 }
}
