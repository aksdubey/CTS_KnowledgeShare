package pkgThreadLC4;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class Main {

    public static void main(String args[]) throws IOException, InterruptedException {
        
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        
        System.out.println("Enter the number of purchases:");
        int numberOfPurchases = Integer.parseInt(reader.readLine());
        System.out.println("Enter all the purchase details (Order ID, Customer ID, Total Amount):");
        List<String> csvInput = new ArrayList<String>();
        for(int i=0;i<numberOfPurchases;i++) {
            csvInput.add(reader.readLine());
        }
        
	// fill in your code here
        List<String> csvInputFirstHalf = csvInput.subList(0, csvInput.size()/2);
        List<String> csvInputSecondHalf = csvInput.subList(csvInput.size()/2, csvInput.size());
        
        CustomerPurchaseThread c1 = new CustomerPurchaseThread(csvInputFirstHalf);
        CustomerPurchaseThread c2 = new CustomerPurchaseThread(csvInputSecondHalf);
        Thread t1 = new Thread(c1);
        Thread t2 = new Thread(c2);
        
        t1.start();
        t2.start();
        t1.join();
        t2.join();
        
        CustomerBO cbo = CustomerBO.getInstance();
        
        List<Customer> alTopThree = cbo.findTopThreeCustomers();
        System.out.println("Top three customers:");
        for(Customer c: alTopThree)
        {
        	System.out.println("Customer ID:" + c.getCustomerId());
        	System.out.println("Total Purchase Amount:" + c.getTotalPurchase());
        }
        
    }
    
}

