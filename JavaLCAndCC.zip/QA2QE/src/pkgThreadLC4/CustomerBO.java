package pkgThreadLC4;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.SortedSet;


public class CustomerBO {

    // fill in your attributes here
	
	List<Customer> alCust = new ArrayList<Customer>();
	private SortedSet<Customer> customerSet;
	private static CustomerBO instance;
	Map<Long, Double> hmCust = new HashMap<Long, Double>();
    
	private CustomerBO() {
        
    }
    
    public static synchronized CustomerBO getInstance() {
        if(instance == null)
            instance = new CustomerBO();
        return instance;
    }
    
    public synchronized void updateCustomerPurchaseValue(Long customerId,Double amount) {
        
       //fill in your code here
    	/*
    	 * This method maintains the customer id and their corresponding total amount 
    	 * in a hash map, This map is updated based on the parameter Customer 
    	 * (This method should be syncronized to prevent multiple threads accessing same data)
    	 */
    	
    	if(hmCust.containsKey(customerId))
    	{
    		hmCust.put(customerId, hmCust.get(customerId) + amount);
    	}
    	else
    	{
    		hmCust.put(customerId, amount);
    	}
    }

    public List<Customer> findTopThreeCustomers() {
        
        //fill in your code here
    	/*
    	 * This methods finds the top 3 customers based on their total purchase value
    	 */
    	    	
    	for(int i=1; i<=3; i++)
    	{
	    	double max= 0;
	    	Long key = null;
	    	for (Entry<Long, Double> entry : hmCust.entrySet())
	    	{
	    		if(entry.getValue() > max)
	    		{
	    			max = entry.getValue();
	    			key = entry.getKey();
	    		}
	    	}
	    	
	    	alCust.add(new Customer(key, max));
	    	hmCust.remove(key);
    	}
    	
    	return alCust;
	
    }

    public SortedSet<Customer> getCustomerSet() {
        return customerSet;
    }

    public void setCustomerSet(SortedSet<Customer> customerSet) {
        this.customerSet = customerSet;
    }
    
    
    
}

