package pkgThreadLC4;

public class Customer implements Comparable<Customer>{

    private Long customerId;
    private Double totalPurchase;

    public Customer(Long customerId,Double totalPurchase) {
        this.customerId = customerId;
        this.totalPurchase = totalPurchase;
    }
    
    public Customer() {
		// TODO Auto-generated constructor stub
	}

	public Long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }

    public Double getTotalPurchase() {
        return totalPurchase;
    }

    public void setTotalPurchase(Double totalPurchase) {
        this.totalPurchase = totalPurchase;
    }

    @Override
    public int compareTo(Customer cust) {
        if(this.totalPurchase > cust.getTotalPurchase()) {
            return -1;
        }else if(this.totalPurchase < cust.getTotalPurchase()) {
            return 1;
        }
        return 0;
    }
    
    public String toString() {
        return customerId + "--" + totalPurchase;
    }
    
    
}

