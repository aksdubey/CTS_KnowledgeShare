package pkgThreadLC4;

import java.util.ArrayList;
import java.util.List;
import java.util.SortedSet;

public class CustomerPurchaseThread implements Runnable// fill in your code here
  {
    
    // fill in your attributes here
	SortedSet<Customer> customerSet;
	CustomerBO cbo = CustomerBO.getInstance();
	//List<Customer> alCust = new ArrayList<Customer>();
	private List<String> input = new ArrayList<String>();
    
    public CustomerPurchaseThread(List<String> input) {
        this.input = input;
    }
    
    public void run() {
       
	//fill in your code here
    	/*
    	 * This method iterates through the purchase list and updates the customer's purchase value
    	 */
    	String[] details = null;
    	for(String str: input)
    	{
    		details = str.split(",");
    		//alCust.add(new Customer(Long.parseLong(details[1]), Double.parseDouble(details[2])));
    		cbo.updateCustomerPurchaseValue(Long.parseLong(details[1]), Double.parseDouble(details[2]));
    	}
    	
    	/*Customer temp = new Customer();
    	int n = alCust.size();
    	for(int i=0; i<n-1; i++)
    	{
    		for(int j=0; j<n-i-1; j++)
    		{
	    		if(alCust.get(i).compareTo(alCust.get(i+1)) > 0)
	    		{
	    			temp = alCust.get(j);
	    			alCust.set(j, alCust.get(j+1));
	    			alCust.set(j+1, temp);	    		
	    		}
    		}
    	}
    	
    	customerSet.addAll(alCust);
    	cbo.setCustomerSet(customerSet);*/
    }
    
}

