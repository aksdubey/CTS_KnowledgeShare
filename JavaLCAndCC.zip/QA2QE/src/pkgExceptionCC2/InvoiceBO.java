package pkgExceptionCC2;


public class InvoiceBO {
	public Item getItemById(Item[] itemArray,int id){
			// fill code here
		//which searches the item by id in the item array and returns the item instance/object
		for(int i=0; i<itemArray.length; i++)
		{
			if(itemArray[i].getId() == id)
			{
				return itemArray[i];
			}
		}
		
		return null;
	}
	
	public void processInvoice(Invoice invoice) throws ItemInsufficientQuantity {
					// fill code here
		/*
		 * Validate whether the quantity specified in the invoice is 
		 * available in the item, if not then throw an exception "ItemInsufficientQuantity". 
		 * If the item is available then reduce the quantity in the item.
		 */
		boolean blnException = false;
		InvoiceLine[] ivLineArray = invoice.getInvoiceLine();
		for(int i=0; i<ivLineArray.length; i++)
		{
			blnException = false;
			if(ivLineArray[i].getItem().getQuantity() >= ivLineArray[i].getQuantity())
			{
				ivLineArray[i].getItem().setQuantity(ivLineArray[i].getItem().getQuantity() - ivLineArray[i].getQuantity());
			}
			else
			{
				blnException = true;
				break;
			}				
		}
		
		if(blnException)
		{
			throw new ItemInsufficientQuantity("Item Insufficient");
		}
	}
}

