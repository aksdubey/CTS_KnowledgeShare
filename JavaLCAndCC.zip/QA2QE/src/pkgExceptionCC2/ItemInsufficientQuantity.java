package pkgExceptionCC2;

public class ItemInsufficientQuantity extends Exception {

	public ItemInsufficientQuantity(String string) {
		// TODO Auto-generated constructor stub
	}
	
	

}
