package pkgOOPSCC2;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Array implements IArray{

	static int i = 0;
    Integer array[] = new Integer[100];
     
    Array(){} 
    Array(Integer array[]){
     this.array = array;
    }
     
    void setArray(Integer array[]){
      this.array = array;
    }
    public Integer[] getArray(){
       return array;
    }
     
    @Override
    public void add(Integer value){

    //fill your code
    	getArray()[i] = value;
    	i++;
          
    }
    @Override
    public void remove(Integer value) {
     
     //fill your code
    	 int len = 0;
    	 for(int i=0; i<array.length; i++)
    	 {
    		 if(array[i] != null)
    		 {
    			 len++;
    		 }
    	 }
    	 
		if(value > len)
		{
			System.out.println("Enter the valid position");
		}
		else
		{
			array[value-1] = null;
			System.out.println("The values are");
			//tempArray = array.getArray();
			for(int i=0; i<array.length; i++)
			{
				if(array[i] != null)
				{
					System.out.println(array[i]);
				}
			}	
		}
    }
    
    @Override
    public void search(Integer value) {
     //fill your code
    	boolean blnFound = false;
    	
    	/*int len = 0;
	   	 for(int i=0; i<array.length; i++)
	   	 {
	   		 if(array[i] != null)
	   		 {
	   			 len++;
	   		 }
	   	 }*/
		for(int i=0; i<array.length; i++)
		{
			if(array[i] == value)
			{
				System.out.println("Element found");
				blnFound = true;
				break;
			}
		}
		if(!blnFound)
		{
			System.out.println("Element not found");
		}
        
    }
    
 
}

