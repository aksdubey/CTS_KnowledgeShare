package pkgOOPSCC2;


public interface IArray {
    
public abstract void add(Integer value);
public abstract void remove(Integer value);
public abstract void search(Integer value);
}


