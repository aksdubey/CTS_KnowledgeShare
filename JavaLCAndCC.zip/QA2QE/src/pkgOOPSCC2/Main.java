package pkgOOPSCC2;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main{
public static void main(String[] args) throws NumberFormatException, IOException
{
    BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
     //fill your code     
    Array array = new Array();
    String decision = null;
    Integer[] tempArray = null;
    
    do
    {
	    System.out.println("Enter your choice\n1.Add\n2.Remove\n3.Search");
	    Integer choice = Integer.parseInt(br.readLine());
	    switch (choice) {
		case 1:
			System.out.println("Enter the array value");
			int arrayValue = Integer.parseInt(br.readLine());
			array.add(arrayValue);
			System.out.println("The values are");
			tempArray = array.getArray();
			for(int i=0; i<tempArray.length; i++)
			{
				if(tempArray[i] != null)
				{
					System.out.println(tempArray[i]);
				}
			}			
			break;
	
		case 2:
			System.out.println("Enter the position to remove");
			int position = Integer.parseInt(br.readLine());
			array.remove(position);
			/*tempArray = array.getArray();
			if(position > tempArray.length)
			{
				System.out.println("Enter the valid position");
			}
			else
			{
				array.remove(tempArray[position-1]);
			}*/
			/*System.out.println("The values are");
			tempArray = array.getArray();
			for(int i=0; i<tempArray.length; i++)
			{
				if(tempArray[i] != null)
				{
					System.out.println(tempArray[i]);
				}
			}	*/
			break;
			
		case 3:
			
			System.out.println("Enter the element to search");
			int search = Integer.parseInt(br.readLine());
			array.search(search);
			/*tempArray = array.getArray();
			for(int i=0; i<tempArray.length; i++)
			{
				if(tempArray[i] == search)
				{
					System.out.println("Element found");
					blnFound = true;
					break;
				}
			}
			if(!blnFound)
			{
				System.out.println("Element not found");
			}*/
			break;
		default:
			break;
		}
	    System.out.println("Do you want to continue[Yes/No]");
		decision = br.readLine();
    }    while(decision.equalsIgnoreCase("Yes"));
   
}

}














