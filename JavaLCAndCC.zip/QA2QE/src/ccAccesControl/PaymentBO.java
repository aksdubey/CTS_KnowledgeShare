package ccAccesControl;


public class PaymentBO {
	
	boolean validateCreditCard(CreditCard creditCard){
			// fill code here
		boolean blnRet = false;
		String ccNo = creditCard.getCardNumber();
		String ssName = creditCard.getCardName();
		if(ccNo.length() == 16)
		{
			if((ccNo.startsWith("34") && ssName.equalsIgnoreCase("American Express"))
					||(ccNo.startsWith("36") && ssName.equalsIgnoreCase("Diner's Club / International"))
					||(ccNo.startsWith("37") && ssName.equalsIgnoreCase("American Express"))
					||(ccNo.startsWith("4") && ssName.equalsIgnoreCase("Visa")))
			{
				blnRet = true;
			}
		}
		
		return blnRet;		
	}
	
	boolean validateCheque(Cheque cheque){
			// fill code here
		boolean blnRet = false;
		String chNo = cheque.getChequeNumber();
		String chName = cheque.getBankName();
		
		if((chNo.startsWith("031176110") && chName.equalsIgnoreCase("CapitalOne"))
			||(chNo.startsWith("021001088") && chName.equalsIgnoreCase("HSBC"))
			||(chNo.startsWith("021000089") && chName.equalsIgnoreCase("Citi bank"))
			||(chNo.startsWith("122101706") && chName.equalsIgnoreCase("Bank of America")))
		{
			blnRet = true;
		}
		
		return blnRet;
	}
}
