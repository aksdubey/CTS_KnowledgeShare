package ccAccesControl;


public class Cheque {
	
	private String bankName;
	private String chequeNumber;
	
	public Cheque(String bankName, String chequeNumber) {
		super();
		this.bankName = bankName;
		this.chequeNumber = chequeNumber;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getChequeNumber() {
		return chequeNumber;
	}

	public void setChequeNumber(String chequeNumber) {
		this.chequeNumber = chequeNumber;
	}
}

