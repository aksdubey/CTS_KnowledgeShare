package ccAccesControl;


public class PaymentMode {
	
	private Integer id;
	private String paymentType;
	
	public PaymentMode(Integer id, String paymentType) {
		super();
		this.id = id;
		this.paymentType = paymentType;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getPaymentType() {
		return paymentType;
	}

	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}
	
	
}
