package pkgExceptionCC1;


public class InvalidDateException extends Exception{
	
	InvalidDateException(String str)
	{
		super(str);
		//super();
		//System.out.println("InvalidDateException: Cheque is valid only for three months");
	}
}

