package pkgExceptionCC1;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class PaymentBO {
	
	private final static double AVERAGE_MILLIS_PER_MONTH = 365.24 * 24 * 60 * 60 * 1000 / 12;
	  
	
	boolean processPayment(Cheque cheque) throws ParseException, InvalidDateException
	{
		/*
		 * to check whether the chequeDate is valid or not,if valid return true or throw InvalidDateException.
		 */
		boolean blnRet = false;
		String strCurrentDate = "15/05/2017";
		Date CurrentDate=new SimpleDateFormat("dd/MM/yyyy").parse(strCurrentDate);
		
		Date ChequeDate = cheque.getChequeDate();
		double months = (ChequeDate.getTime() - CurrentDate.getTime()) / AVERAGE_MILLIS_PER_MONTH;
		//System.out.println("Months: \n" + months);
		
		if(months <=3 && months >= 0)
		{	
			blnRet = true;
			//System.out.println("Cheque is sent to clearing house");
		}
		else
		{			
			//blnRet = false;
			throw new InvalidDateException("InvalidDateException: Cheque is valid only for three months");
		}
		
		return blnRet;
		
		
	}
}

