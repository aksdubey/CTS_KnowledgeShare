package pkgExceptionCC1;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;
public class Main {
	public static void main(String args[]) throws ParseException{
		
		PaymentBO pbo = new PaymentBO();
		Scanner in = new Scanner(System.in);
		System.out.println("Enter the cheque details\nEnter the bank name :");
		String BankName = in.nextLine();
		
		System.out.println("Enter the cheque number :");
		String ChequeNumber = in.nextLine();
		
		System.out.println("Enter the cheque date :");
		Date ChequeDate=new SimpleDateFormat("dd/MM/yyyy").parse(in.nextLine());
		//Date ChequeDate = Date.parse(in.nextLine());
		
		Cheque cheque = new Cheque(BankName, ChequeNumber, ChequeDate);
		
		try{
			if(pbo.processPayment(cheque))
			{
				System.out.println("Cheque is sent to clearing house");
			}
			/*else	
			{
				System.out.println("InvalidDateException: Cheque is valid only for three months");
			}*/
		}
		catch(InvalidDateException iex)
		{
			//iex.getMessage();
			//System.out.println("InvalidDateException: Cheque is valid only for three months");
			//System.out.println("InvalidDateException: Cheque is valid only for three months");
		}
		
		in.close();
		
	}
}

