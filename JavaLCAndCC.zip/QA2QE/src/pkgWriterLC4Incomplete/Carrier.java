package pkgWriterLC4Incomplete;

import java.util.List;

public class Carrier {
	
	private Long carrierId;
	private String name;
	private String code;
	private List<Shipment> shipmentList;
	public Long getCarrierId() {
		return carrierId;
	}
	public void setCarrierId(Long carrierId) {
		this.carrierId = carrierId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public List<Shipment> getShipmentList() {
		return shipmentList;
	}
	public void setShipmentList(List<Shipment> shipmentList) {
		this.shipmentList = shipmentList;
	}
	public Carrier(Long carrierId, String name, String code,
			List<Shipment> shipmentList) {
		super();
		this.carrierId = carrierId;
		this.name = name;
		this.code = code;
		this.shipmentList = shipmentList;
	}

	
}
