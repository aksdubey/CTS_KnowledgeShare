package pkgWriterLC4Incomplete;

import java.util.Date;

public class Shipment {
	
	private Long id;
	private String bookingNumber;
	private Date departureDate;
	private Date arrivalDate;
	private Integer totalWeight;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getBookingNumber() {
		return bookingNumber;
	}
	public void setBookingNumber(String bookingNumber) {
		this.bookingNumber = bookingNumber;
	}
	public Date getDepartureDate() {
		return departureDate;
	}
	public void setDepartureDate(Date departureDate) {
		this.departureDate = departureDate;
	}
	public Date getArrivalDate() {
		return arrivalDate;
	}
	public void setArrivalDate(Date arrivalDate) {
		this.arrivalDate = arrivalDate;
	}
	public Integer getTotalWeight() {
		return totalWeight;
	}
	public void setTotalWeight(Integer totalWeight) {
		this.totalWeight = totalWeight;
	}
	public Shipment(Long id, String bookingNumber, Date departureDate,
			Date arrivalDate, Integer totalWeight) {
		super();
		this.id = id;
		this.bookingNumber = bookingNumber;
		this.departureDate = departureDate;
		this.arrivalDate = arrivalDate;
		this.totalWeight = totalWeight;
	}
	
	
	
	

}
