package pkgWriterLC4Incomplete;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;



public class Main {
	
	public static void main(String args[]) throws NumberFormatException, IOException, ParseException
	{
		BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream("input.txt")));
		BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("output.txt")));
		String line;
		String[] details;
		List<Shipment> listShip = new ArrayList<Shipment>();
		List<Carrier> listCarr = new ArrayList<Carrier>();
		while((line=reader.readLine()) != null)
		{
			details = line.split(",");
			listShip.add(new Shipment(Long.parseLong(details[0]), details[1], 
					new SimpleDateFormat("dd/MM/yyyy").parse(details[2]), 
					new SimpleDateFormat("dd/MM/yyyy").parse(details[3]), Integer.parseInt(details[4])));
			listCarr.add(new Carrier(Long.parseLong(details[5]), details[6], details[7], listShip));
		}
	}	

}
