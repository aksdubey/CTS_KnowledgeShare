package pkgExceptionCC3;

public class UserBO {
    
    //fill code here.
	void validatePassword(User user) throws WeakPasswordException
	{
		/*
		 * In this method, validate the password whether it is strong or weak. 
		 * If it is weak then throw the exception WeakPasswordException.
		 */
		String pwd = user.getPassword();
		if((pwd.length() >= 8) && (pwd.matches(".*\\d+.*")) && ((pwd.contains("!")) || (pwd.contains("@")) 
				|| (pwd.contains("#")) || (pwd.contains("$")) || (pwd.contains("%"))))
		{
			//System.out.println("Password is strong");
		}
		else
		{
			throw new WeakPasswordException("Password is weak");
		}
	}
 
}
