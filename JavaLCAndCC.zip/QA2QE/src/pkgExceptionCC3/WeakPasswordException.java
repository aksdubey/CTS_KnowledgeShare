package pkgExceptionCC3;

public class WeakPasswordException extends Exception {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	//fill code here
	WeakPasswordException(String message)
	{
		super(message);
		//System.out.println(message);
	}

}
