package pkgExceptionCC3;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) throws Exception {
        UserBO userBO = new UserBO();
    	Scanner in = new Scanner(System.in);
        System.out.println("Enter user name :");
        // fill code here.
        String userName = in.nextLine();
        System.out.println("Enter password :");
        // fill code here.
        String passwd = in.nextLine();
        System.out.println("Enter address :");
        // fill code here.
        String address = in.nextLine();
		// fill code here.
        User user = new User(userName, passwd, address);
        try{
        	userBO.validatePassword(user);
        	System.out.println("Password is strong");
        }
        catch(WeakPasswordException wex)
        {
        	//System.out.println("WeakPasswordException: Password is weak");
        	//System.out.println(wex.getMessage());
        	System.out.println(wex.toString());
        }
        in.close();
    }
    
}
