package pkgJDBCLC4;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.List;
public class Main {

    public static void main(String[] args) throws Exception {
        int choice,roleId;
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        User user = null;
        RoleDAO roleDAO = new RoleDAO();
        UserDAO userDAO = new UserDAO();
        List<Role> tempList = null;
        String[] details;
        while(true)
        {
            System.out.println("1. Create User\n2. Display Details\n3. Exit\nEnter the choice :");
            choice = Integer.parseInt(br.readLine());
            switch(choice)
            {
                case 1:
                    System.out.println("Enter the user details:");
                    //fill code here.
                    details = br.readLine().split(",");
                    
                    System.out.println("Role details:");
                    System.out.format("%-15s %-25s %s\n","Role id","Role name","Role description");
                    //fill code here.
                    tempList = roleDAO.getAllRoles();
                    
                    for(Role r: tempList)
                    {
                    	System.out.format("%-15s %-25s %s\n",r.getId(),r.getRoleName(),r.getDescription());
                    }
                    
                    System.out.println("Enter the role id:");
                    roleId = Integer.parseInt(br.readLine());
                    //fill code here.
                    //check role name from id
                    for(Role r: tempList)
                    {
                    	if(r.getId() == roleId)
                    	{
                    		user = new User(details[0], details[1], details[2], details[3], r);
                    		break;
                    	}
                    }
                    
                    //create User
                    userDAO.createUser(user);
                    break;
                case 2:
					//fill code here.
                	userDAO.displayDetails();
                    break;
                case 3:
                    System.exit(0);
            }
        }
    }
    
}

