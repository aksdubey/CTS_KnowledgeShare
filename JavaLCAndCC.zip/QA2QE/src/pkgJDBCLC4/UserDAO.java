package pkgJDBCLC4;

import java.sql.*;



public class UserDAO {
    
public void createUser(User user) throws Exception
{
    //fill code here.
	/*
	 * This method is used to insert the new users data to the user table in database.
	 */
	Connection con = DbConnection.getConnection();
	Statement stmt=con.createStatement();  
	stmt.executeUpdate("INSERT INTO `user` (`name`, `username`, `password`, `mobile number`, `role`) "
			+ "VALUES ('" + user.getName() + "', '" + user.getUserName() + "', '" 
			+ user.getPassword() + "', '" + user.getMobileNumber() + "', '" + user.getRole().getRoleName() + "')");
}
    
    public void displayDetails() throws Exception
    {
    	/*
    	 * This method is to display all the newly created users with their details.
    	 */
        System.out.println("User details:");
        System.out.format("%-15s %-15s %-15s %-15s %-15s %s\n",
        		"User id","Name","User name","Password","Mobile number","Role");
        //fill code here.
        
        Connection con = DbConnection.getConnection();
		Statement stmt=con.createStatement();  
		ResultSet rs=stmt.executeQuery("select * from user");
		
		while(rs.next())
		{
			System.out.format("%-15s %-15s %-15s %-15s %-15s %s\n",
					rs.getInt(1),rs.getString(2),rs.getString(3),
					rs.getString(4),rs.getString(5),rs.getString(6));
		}
		
		stmt.close();
		rs.close();
		con.close(); 
    }
    
}

