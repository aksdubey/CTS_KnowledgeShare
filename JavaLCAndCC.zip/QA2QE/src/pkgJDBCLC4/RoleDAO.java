package pkgJDBCLC4;

import java.sql.*;
import java.util.*;
public class RoleDAO {
    
    public List<Role> getAllRoles() throws Exception
    {
        //fill code here.
    	/*
    	 * In this method, retrieve and display the Role details from database sorted based on role name.
    	 */
    	//fill code here.
        
    	List<Role> list = new ArrayList<Role>();
        Connection con = DbConnection.getConnection();
		Statement stmt=con.createStatement();  
		ResultSet rs=stmt.executeQuery("select * from role order by name");
		
		while(rs.next())
		{
			list.add(new Role(rs.getInt(1),rs.getString(2),rs.getString(3)));
			//System.out.format("%-15s %-25s %s\n",rs.getInt(1),rs.getString(2),rs.getString(3));
		}
		
		stmt.close();
		rs.close();
		con.close(); 
		
		return list;
    }
    
}

