package pkgThreadsCC1;




import java.util.ArrayList;
import java.util.List;

public class SearchProviderThread extends Thread{//fill in your code here

    //fill in your attributes here
	private String itemName;
	private List<Item> itemList = new ArrayList<Item>();  
	private List<Item> filteredItems = new ArrayList<Item>();
    
	/*public SearchProviderThread(String name) {
        super(name);
    }*/
	
    public SearchProviderThread(String itemName,List<Item> itemList) {
        this.itemName = itemName;
        this.itemList = itemList;
    }
    
    @Override
    public void run() {
        
       //fill in your code here
    	/*
    	 * Override the run method, and iterate through the item list and 
    	 * find the least pricing vendor for that item and add it to the filtered list.
    	 */
    	for(Item i: itemList)
    	{
    		if(i.getName().equalsIgnoreCase(itemName))
    		{
    			filteredItems.add(i);
    		}
    	}
        
    }

    public List<Item> getFilteredItems() {
        return filteredItems;
    }

    public void setFilteredItems(List<Item> filteredItems) {
        this.filteredItems = filteredItems;
    }
    
    
}
