package pkgCollectionsLC3;

public class MyOwnInteger implements Comparable<MyOwnInteger>{
	
	private Integer number;
	
	public MyOwnInteger(int i) {
		// TODO Auto-generated constructor stub
		number = i;
	}
	
	public Integer getNumber() {
		return number;
	}

	public void setNumber(Integer number) {
		this.number = number;
	}

	@Override
	public int compareTo(MyOwnInteger objMyOwnInteger) {
		// TODO Auto-generated method stub
		int iRet = 0;
		int n1 = this.getNumber();
		int n2 = objMyOwnInteger.getNumber();
		//negative comparison
		if(n1 < n2)
		{
			iRet = -1;
		}
		else if(n1 > n2)
		{
			iRet = 1;
		}
		return iRet;
	}

}
