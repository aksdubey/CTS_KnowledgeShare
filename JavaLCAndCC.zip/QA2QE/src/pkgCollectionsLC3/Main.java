package pkgCollectionsLC3;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;



public class Main {
	
	public static void main(String args[]) throws IOException{
		 
		List<Integer> poslist = new ArrayList<Integer>();
		List<Integer> neglist = new ArrayList<Integer>();
		int eachNo, n1, n2;
		//MyOwnInteger myOwnInteger = new MyOwnInteger();
		 BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		   //fill your code
		 	System.out.println("Enter n");
		 	int temp;
		 	int No = Integer.parseInt(br.readLine());
		 	for(int i=0; i<No; i++)
		 	{
		 		eachNo = Integer.parseInt(br.readLine());
		 		if(eachNo < 0)
		 		{
		 			neglist.add(eachNo);
		 		}
		 		else
		 		{
		 			poslist.add(eachNo);
		 		}
		 	}
		 			 	
		 	for(int i=0; i<neglist.size(); i++)
		 	{
		 		for(int j=1; j<(neglist.size()-i); j++)
		 		{  
			 		n1 = neglist.get(j-1);
			 		n2 = neglist.get(j);
			 		if(new MyOwnInteger(n1).compareTo(new MyOwnInteger(n2)) > 0)
			 		{
			 			temp = neglist.get(j-1);  
			 			neglist.set(j-1, neglist.get(j));  
			 			neglist.set(j, temp);
			 		}
		 		}
		 	}
		 	
		 	for(int i=0; i<poslist.size(); i++)
		 	{
		 		for(int j=1; j<(poslist.size()-i); j++)
		 		{  
			 		n1 = poslist.get(j-1);
			 		n2 = poslist.get(j);
			 		if(new MyOwnInteger(n1).compareTo(new MyOwnInteger(n2)) < 0)
			 		{
			 			temp = poslist.get(j-1);  
			 			poslist.set(j-1, poslist.get(j));  
                        poslist.set(j, temp);  
			 		}
		 		}
		 	}
		 	
		 	System.out.print("[");
		 	for(int i=0; i<neglist.size(); i++)
		 	{
		 		System.out.print(neglist.get(i) + ", ");
		 	}
		 	for(int i=0; i<poslist.size(); i++)
		 	{
		 		if(i == poslist.size()-1)
		 		{
		 			System.out.print(poslist.get(i));
		 		}
		 		else
		 		{
		 			System.out.print(poslist.get(i) + ", ");
		 		}
		 	}
		 	System.out.print("]");
		 	
	}

}
