package pkgJDBCLC1;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class RoleDAO {

    public ArrayList<Role> getAllRoles() throws ClassNotFoundException, SQLException {
    	ArrayList<Role> list = new ArrayList<Role>();
    	Connection con = DbConnection.getConnection();
		Statement stmt=con.createStatement();  
		ResultSet rs=stmt.executeQuery("select * from role order by name");
		
		while(rs.next())
		{
			list.add(new Role(rs.getInt(1), rs.getString(2)));
		}
			con.close();  
			
			return list;
      // fill the code
    }

}
