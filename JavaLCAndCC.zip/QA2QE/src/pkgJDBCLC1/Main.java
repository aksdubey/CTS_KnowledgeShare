package pkgJDBCLC1;

import java.sql.SQLException;
import java.util.ArrayList;

public class Main {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
        // fill the code
		RoleDAO rd = new RoleDAO();
		ArrayList<Role> allRoles = rd.getAllRoles();
		
		System.out.println("Role Details:");
		for(Role r: allRoles)
		{
			System.out.println(r.getName());
		}
		
    }

}

