package pkgOOPSLC4;

public class ShipmentEntity {
    
    protected String shipmentEntityName;
    protected String identificationNumber;
    
    //fill your code
    public void setShipmentEntityName(String shipmentEntityName){
      this.shipmentEntityName = shipmentEntityName;
    }
    
    public String getShipmentEntityName(){
    return shipmentEntityName;
    }
    
    public void setIdentificationNumber(String identificationNumber){
      this.identificationNumber = identificationNumber;
    }
    
    public String getIdentificationNumber(){
    return identificationNumber;
    }
        // fill your code here

	public ShipmentEntity(String shipmentEntityName, String identificationNumber) {
		//super();
		this.shipmentEntityName = shipmentEntityName;
		this.identificationNumber = identificationNumber;
	}
	
	public ShipmentEntity()
	{
		
	}
	
	void display()
	{
		
	}
    
    
}
