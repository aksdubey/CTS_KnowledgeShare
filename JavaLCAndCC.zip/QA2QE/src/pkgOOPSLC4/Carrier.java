package pkgOOPSLC4;


public class Carrier extends ShipmentEntity {
    
   private String carrierCode;
   private String iata;
  
   //fill your code
    
      public void setCarrierCode(String carrierCode){
      this.carrierCode = carrierCode;
     }
     public String getCarrierCode(){
      return carrierCode;
     }
     
    
     public void setIata(String iata){
      this.iata = iata;
     }
     public String getIata(){
      return iata;
     }
     // fill your code here
	public Carrier(String shipmentEntityName, String identificationNumber,
			String carrierCode, String iata) {
		super(shipmentEntityName, identificationNumber);
		this.carrierCode = carrierCode;
		this.iata = iata;
	}
     
     public Carrier() {
		// TODO Auto-generated constructor stub
	}
     
    @Override
	void display()
     {
    	 System.out.format("%-15s %-25s %-15s %-15s\n",
    			 this.getShipmentEntityName(),this.identificationNumber,this.carrierCode,this.iata);
     }
}
