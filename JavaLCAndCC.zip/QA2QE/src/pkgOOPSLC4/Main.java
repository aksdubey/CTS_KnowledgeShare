package pkgOOPSLC4;


import java.io.IOException;
import java.text.ParseException;
import java.util.Scanner;
public class Main {
    
    public static void main(String args[]) throws IOException, ParseException{
      //fill your code
    	int entityType;
    	String[] details = null;
    	Scanner in = new Scanner(System.in);
    	System.out.println("Enter the number of shipment entity");
    	int No = Integer.parseInt(in.nextLine());
    	Customer[] customer = new Customer[No];
    	Company[] company = new Company[No];
    	Agent[] agent = new Agent[No];
    	Carrier[] carrier = new Carrier[No];
    	for(int i=0; i<No; i++)
    	{
    		System.out.println("Enter the shipment entity " + (i+1) + " details :");
    		System.out.println("Select the shipment entity type\n1)Customer\n2)Company\n3)Agent\n4)Carrier");
    		entityType = Integer.parseInt(in.nextLine());
    		switch (entityType) {
			case 1:
				details = in.nextLine().split(",");
				customer[i] = new Customer(details[0], details[1], Integer.parseInt(details[2]), details[3]);
				break;
			case 2:
				details = in.nextLine().split(",");
				company[i] = new Company(details[0], details[1], details[2], details[3], details[4]);
				break;
			case 3:
				details = in.nextLine().split(",");
				agent[i] = new Agent(details[0], details[1], details[2], details[3], details[4]);
				break;
			case 4:
				details = in.nextLine().split(",");
				carrier[i] = new Carrier(details[0], details[1], details[2], details[3]);
				break;
			default:
				break;
			}
    	}
    	
    	System.out.println("Shipment details are\nEnter the shipment entity type to display");
    	String shipmentEntityToDisplay = in.nextLine();
    	if(shipmentEntityToDisplay.equalsIgnoreCase("Customer"))
    	{
    		System.out.format("%-15s %-25s %-15s %-15s\n",
        			"Name","Identification Number","Customer Id","Customer Name");
    		for(int i=0; i<No; i++)
    		{    			
    			if(customer[i]!=null)
    			{
    				customer[i].display();
    			}
    		}
    	}
    	else if(shipmentEntityToDisplay.equalsIgnoreCase("Company"))
    	{
    		System.out.format("%-15s %-25s %-15s %-15s %-15s\n",
        			"Name","Identification Number","Company Name","IATA","FMC");
    		for(int i=0; i<No; i++)
    		{    			
    			if(company[i]!=null)
    			{
    				company[i].display();
    			}
    		}
    	}
    	else if(shipmentEntityToDisplay.equalsIgnoreCase("Agent"))
    	{
    		System.out.format("%-15s %-25s %-15s %-15s %-15s\n",
       			 "Name","Identification Number ","Agent Name","IATA","FMC");
    		for(int i=0; i<No; i++)
    		{    			
    			if(agent[i]!=null)
    			{
    				agent[i].display();
    			}
    		}
    	}
    	else if(shipmentEntityToDisplay.equalsIgnoreCase("Carrier"))
    	{
    		System.out.format("%-15s %-25s %-15s %-15s\n",
       			 "Name","Identification Number","Code Name","IATA");
    		for(int i=0; i<No; i++)
    		{    			
    			if(carrier[i]!=null)
    			{
    				carrier[i].display();
    			}
    		}
    	}
    	
    	in.close();
    	
    }
}


