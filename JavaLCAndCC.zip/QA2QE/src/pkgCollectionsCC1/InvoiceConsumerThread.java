package pkgCollectionsCC1;

import java.util.concurrent.BlockingQueue;

public class InvoiceConsumerThread extends Thread{
	private BlockingQueue<Invoice> sharedQueue;

	public InvoiceConsumerThread(BlockingQueue<Invoice> sharedQueue) {
		super();
		this.sharedQueue = sharedQueue;
	}
	
	public void run(){
		//fill the code
		//To take invoices added by producer thread using take() method.
		try {
            System.out.println("Invoice "+ sharedQueue.take().getInvoiceNumber() + " consumed");
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
