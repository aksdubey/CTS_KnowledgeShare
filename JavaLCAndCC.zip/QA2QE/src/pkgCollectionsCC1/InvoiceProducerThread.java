package pkgCollectionsCC1;

import java.util.List;
import java.util.concurrent.BlockingQueue;

public class InvoiceProducerThread extends Thread{
	
	private BlockingQueue<Invoice> sharedQueue;
	private List<Invoice> invoiceList;
	public InvoiceProducerThread(BlockingQueue<Invoice> sharedQueue,List<Invoice> invoiceList) {
		super();
		this.sharedQueue = sharedQueue;
		this.invoiceList = invoiceList;
	}
	
	public void run(){
		//fill the code
		//To add invoices to the blocking queue by using add() method.
		for(Invoice invoices: invoiceList)
		{
			sharedQueue.add(invoices);
			System.out.println("Invoice " + invoices.getInvoiceNumber() + " produced");
		}
	}
}

