package pkgCollectionsCC1;

import java.util.Date;

public class Invoice {
	private String invoiceNumber;
	private Date dueDate;
	private String status;
	private Double amount;
	private Boolean lastInvoice;
	
	public Invoice(String invoiceNumber, Date dueDate, String status, Double amount,Boolean lastInvoice) {
		super();
		this.invoiceNumber = invoiceNumber;
		this.dueDate = dueDate;
		this.status = status;
		this.amount = amount;
		this.lastInvoice = lastInvoice;
	}

	public Boolean getLastInvoice() {
		return lastInvoice;
	}

	public void setLastInvoice(Boolean lastInvoice) {
		this.lastInvoice = lastInvoice;
	}

	public String getInvoiceNumber() {
		return invoiceNumber;
	}

	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}

	public Date getDueDate() {
		return dueDate;
	}

	public void setDueDate(Date dueDate) {
		this.dueDate = dueDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}
}
