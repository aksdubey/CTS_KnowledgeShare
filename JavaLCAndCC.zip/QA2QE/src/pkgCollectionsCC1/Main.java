package pkgCollectionsCC1;

import java.io.*;
import java.util.concurrent.*;
import java.util.*;
import java.text.*;
public class Main {

	public static void main(String[] args) throws IOException, NumberFormatException, ParseException, InterruptedException{
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		BlockingQueue<Invoice> invoiceSharedQueue = new LinkedBlockingQueue<Invoice>();
		BufferedReader buf = new BufferedReader(new InputStreamReader(System.in));
		List<Invoice> invoiceList = new ArrayList<Invoice>();
		String ch;
		String[] invoiceDetail;
		do{
			System.out.println("Enter the invoice detail:");
			invoiceDetail = buf.readLine().split(",");
			Boolean last = (invoiceDetail[4].equals("yes")) ? true : false;
			invoiceList.add(new Invoice(invoiceDetail[0],
					sdf.parse(invoiceDetail[1]),
					invoiceDetail[2],
					Double.parseDouble(invoiceDetail[3]),
					last));
			System.out.println("Do you want to raise one more invoice?(yes/no)");
			ch = buf.readLine();
		}while(ch.equals("yes"));
		
		//fill the code
		
		InvoiceProducerThread producer = new InvoiceProducerThread(invoiceSharedQueue, invoiceList);
		InvoiceConsumerThread consumer = new InvoiceConsumerThread(invoiceSharedQueue);
		new Thread(producer).start();
		for(int i=0; i<invoiceList.size(); i++)
		{
			new Thread(consumer).start();
		}
	}

}
