package pkgExceptionLC1AndC2;

import java.io.*;
import java.util.Scanner;

public class Main2 {

	public static void main(String[] args) throws NumberFormatException, IOException {
		// TODO Auto-generated method stub
		
		System.out.println("Enter the total number of items");
		Scanner in = new Scanner(System.in);
		int No = Integer.parseInt(in.nextLine());
		int sum=0;
		for(int i= 0; i< No; i++)
		{
			System.out.println("Enter the shipping price of the item " + (i+1) + " :");
			try{
				sum = sum + Integer.parseInt(in.nextLine());
			}
			catch(NumberFormatException nex)
			{
				System.out.println("Exception : java.lang.NumberFormatException");
				System.out.println("Re-enter the item price :");
				sum = sum + Integer.parseInt(in.nextLine());
			}
		}
		
		System.out.println("Total cost of the container is " + sum);
		in.close();

	}

}
