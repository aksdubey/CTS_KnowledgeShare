package pkgExceptionLC1AndC2;

import java.util.Scanner;

public class Main1 {

	public static void main(String args[])
	{
		System.out.println("Enter the container price :");
		Scanner in = new Scanner(System.in);
		int Price = Integer.parseInt(in.nextLine());
		System.out.println("Enter the number of items in the container :");
		int No = Integer.parseInt(in.nextLine());
		try{
			int div = Price/No;
			System.out.println("The average price of the item is Rs." + div);
		}
		catch(ArithmeticException ax)
		{
			System.out.println("Exception : java.lang.ArithmeticException");
		}
		
		in.close();
	}
}
