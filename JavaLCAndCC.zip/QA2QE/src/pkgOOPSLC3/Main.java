package pkgOOPSLC3;

import java.io.*;
import java.text.DecimalFormat;

public class Main {

    public static void main(String[] args) throws Exception {
    	DecimalFormat df = new DecimalFormat("##.00");
        String name,source,destination;
        double price;
        int choice;
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Enter the shipment name :");
        name = br.readLine();
        System.out.println("Enter the source :");
        source = br.readLine();
        System.out.println("Enter the destination :");
        destination = br.readLine();
        System.out.println("Enter the price :");
        price =Double.parseDouble(br.readLine());
        System.out.println("1. Agent\n2. Company\nEnter your choice :");
        choice = Integer.parseInt(br.readLine());
        //Shipment shipment;
        
        if(choice == 1)
        {
            double referalFee;
            System.out.println("Enter the referal fee :");
            referalFee = Double.parseDouble(br.readLine());
            System.out.println("Agent details :");
			//fill code here.
            System.out.format("%-15s %-15s %-15s %s\n","Name","Source","Destination","Total Amount");
			//fill code here.
            AgentShipment agentShipment = new AgentShipment(name, source, destination, price, referalFee);
            System.out.format("%-15s %-15s %-15s %s\n",agentShipment.getName(),
            		agentShipment.getSource(),agentShipment.getDestination(),
            		df.format(agentShipment.calculateShipmentAmount()).toString());
        }
        else if(choice == 2)
        {
            double luxuryTax,corporateTax;
            System.out.println("Enter the luxury tax and corporate tax:");
            luxuryTax = Double.parseDouble(br.readLine());
            corporateTax = Double.parseDouble(br.readLine());
            System.out.println("Company details :");
			//fill code here.
            System.out.format("%-15s %-15s %-15s %s\n","Name","Source","Destination","Total Amount");
			//fill code here.
            CompanyShipment companyShipment = new CompanyShipment(name, source, destination, price, luxuryTax, corporateTax);
            System.out.format("%-15s %-15s %-15s %s\n",companyShipment.getName(),
            		companyShipment.getSource(),companyShipment.getDestination(),
            		df.format(companyShipment.calculateShipmentAmount()).toString());
        }
    }
    
}

