package pkgJDBCCC1;

import java.sql.Date;
import java.util.ArrayList;


public class Shipment {

	
	private Integer	id ;
	private String name; 
	private String arrivalPort;
	private String departurePort;
	private Date arrivalDate;
	private Date departureDate;
	ArrayList<Cargo> cargoList = new ArrayList<Cargo>();
	
	Shipment(){}
	Shipment(Integer id,String name,String arrivalPort,String departurePort,Date arrivalDate,Date departureDate){
		this.id =id;
		this.name=name;		
		this.arrivalPort = arrivalPort;
		this.departurePort = departurePort;
		this.arrivalDate=arrivalDate;
		this.departureDate=departureDate;
	}
	
	public String getArrivalPort() {
		return arrivalPort;
	}
	public void setArrivalPort(String arrivalPort) {
		this.arrivalPort = arrivalPort;
	}


	public String getDeparturePort() {
		return departurePort;
	}

	public void setDeparturePort(String departurePort) {
		this.departurePort = departurePort;
	}


	public Date getArrivalDate() {
		return arrivalDate;
	}

	public void setArrivalDate(Date arrivalDate) {
		this.arrivalDate = arrivalDate;
	}

	public Date getDepartureDate() {
		return departureDate;
	}

	public void setDepartureDate(Date departureDate) {
		this.departureDate = departureDate;
	}

	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public ArrayList<Cargo> getCargoList() {
		return cargoList;
	}
	public void setCargoList(ArrayList<Cargo> cargoList) {
		this.cargoList = cargoList;
	} 

	
}

