package pkgJDBCCC1;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.List;

public class Main {
  public static void main(String ags[])throws Exception{
  
    //fill your code
	  BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	  ShipmentDAO sdao = new ShipmentDAO();
	System.out.println("List all cargos");
	System.out.format("%-10s %-30s %-15s\n","Id","Name","Weight");
	List<Cargo> listCargos = sdao.getAllCargos();
	
	for(Cargo c: listCargos)
	{
		System.out.format("%-10s %-30s %-15s\n",c.getId(),c.getName(),c.getWeight());
	}
	
	
	System.out.println("Enter the cargo id");
	int id = Integer.parseInt(br.readLine());
	Cargo cargo = sdao.findCargoByCargoId(id);
	Shipment sh = sdao.getShipmentByCargo(cargo);
	System.out.println("Cargo Name : " + sh.getName());
	System.out.println("Arrival Port : " + sh.getArrivalPort());
	System.out.println("Departure Port : " + sh.getDeparturePort());
	System.out.println("Arrival Date : " + sh.getArrivalDate());
	System.out.println("Departure Date : " + sh.getDepartureDate());
  }
}



