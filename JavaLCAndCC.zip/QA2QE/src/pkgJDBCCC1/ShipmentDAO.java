package pkgJDBCCC1;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;



public class ShipmentDAO {


  Cargo findCargoByCargoId(Integer id) throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException{
    //fill your code
	  Cargo cargo = null;
		Connection con = DbConnection.getConnection();
		Statement stmt=con.createStatement();  
		ResultSet rs=stmt.executeQuery("select * from cargo where id = " + id);
		
		rs.next();
		cargo = new Cargo(rs.getInt(1), rs.getString(1), rs.getDouble(6));
		
		stmt.close();
		rs.close();
		con.close();
		
		return cargo;
	  
  }
  Shipment getShipmentByCargo(Cargo cargo) throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException{
   //fill your code 
	  
	  Shipment shipment = null;
		Connection con = DbConnection.getConnection();
		Statement stmt=con.createStatement();  
		ResultSet rs=stmt.executeQuery("select * from shipment where cargo_id = " + cargo.getId());
		
		rs.next();
		shipment = new Shipment(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getDate(5), rs.getDate(6));
		
		stmt.close();
		rs.close();
		con.close();
		
		return shipment;

  }
 
  List<Cargo> getAllCargos() throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException{
  //fill your code
	  List<Cargo> list = new ArrayList<Cargo>();
  		Connection con = DbConnection.getConnection();
		Statement stmt=con.createStatement();  
		ResultSet rs=stmt.executeQuery("select * from cargo order by id");
		
		while(rs.next())
		{
			list.add(new Cargo(rs.getInt(1),rs.getString(2),rs.getDouble(6)));
		}
		
		stmt.close();
		rs.close();
		con.close();
		
		return list;
 }
 
}



