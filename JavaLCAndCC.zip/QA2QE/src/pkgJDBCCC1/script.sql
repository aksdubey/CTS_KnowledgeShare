drop table if exists cargo;
drop table if exists shipment;


create table cargo(
id int not null auto_increment,
name varchar(30) not null,
length double not null,
width double not null,
height double not null,
weight double not null,
primary key(id));

create table shipment(
id int not null auto_increment,
name varchar(30) not null,
arrival_port varchar(30) not null,
departure_port varchar(30) not null,
arrival_date date not null,
departure_date date not null,
cargo_id int not null,
primary key(id),
foreign key(cargo_id)
references cargo(id));



insert into cargo(name,length,width,height,weight) values ('Dry storage container',6.00,2.54,6.25,1500.00);
insert into cargo(name,length,width,height,weight) values ('Drums',7.00,3.54,5.25,2500.00);
insert into cargo(name,length,width,height,weight) values ('Car carriers',6.25,1.54,5.25,2000.00);
insert into cargo(name,length,width,height,weight) values ('Half height containers',5.00,3.24,5.75,1780.00);
insert into cargo(name,length,width,height,weight) values ('Tanks',7.00,3.74,7.15,1800.00);
insert into cargo(name,length,width,height,weight) values ('Refrigerated ISO containers',5.80,4.00,6.85,2800.00);
insert into cargo(name,length,width,height,weight) values ('Open top container',7.00,4.28,7.28,2400.00);
insert into cargo(name,length,width,height,weight) values ('Flat rack container',6.50,2.50,6.50,1870.00);



insert into shipment(name,arrival_port,departure_port,arrival_date,departure_date,cargo_id) values
('Charter','Kandla','Paradip','2017-06-16','2017-07-14',1);
insert into shipment(name,arrival_port,departure_port,arrival_date,departure_date,cargo_id) values
('Charter','Sydney','Ulladulla','2017-05-22','2017-06-01',5);
insert into shipment(name,arrival_port,departure_port,arrival_date,departure_date,cargo_id)  values
('Charter','Ulladulla','Wollongong','2017-11-16','2017-12-03',4) ;
insert into shipment(name,arrival_port,departure_port,arrival_date,departure_date,cargo_id)  values
('Livestock','Kandla','Sydney','2017-03-16','2017-07-11',2) ;
insert into shipment(name,arrival_port,departure_port,arrival_date,departure_date,cargo_id)  values
('Livestock','Paradip','Ulladulla','2017-04-16','2017-05-10',3) ;
insert into shipment(name,arrival_port,departure_port,arrival_date,departure_date,cargo_id)  values
('Tug','Yamba','Paradip','2017-11-16','2017-12-07',6) ;
insert into shipment(name,arrival_port,departure_port,arrival_date,departure_date,cargo_id)  values
('Tug','Galle','Colombo','2017-05-16','2017-06-13',7) ;
insert into shipment(name,arrival_port,departure_port,arrival_date,departure_date,cargo_id)  values
('Tug','Galle','Pedro','2017-09-16','2017-10-11',8) ;



