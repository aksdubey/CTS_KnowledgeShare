package pkgThreadsLC2;



import java.text.SimpleDateFormat;
import java.util.List;

public class ExportShipmentThread implements Runnable 
{
	private List<Shipment> shipmentList;
	private StringBuilder shipmentDetails = new StringBuilder();
    //fill in your attributes

	SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
	
    public ExportShipmentThread(List<Shipment> shipmentList) {
        this.shipmentList = shipmentList;
    }
    
    public void run() {
        
           //fill in your code here
    	for(Shipment sh: shipmentList)
    	{
    		shipmentDetails.append(sh.getId().toString()).append("|")
    				.append(sh.getName()).append("|") 
    				.append(sh.getBookingNumber().toString()).append("|") 
    				.append(sh.getExecutedPlace()).append("|") 
    				.append(sdf.format(sh.getExecutedDate()).toString()).append("|")
    				.append((sh.getDepartureDate() ==  null)? "":sdf.format(sh.getDepartureDate()).toString()).append("|")
    				.append((sh.getArrivalDate() ==  null)? "":sdf.format(sh.getArrivalDate()).toString()).append("|") 
    				.append(sh.getTotalWeight().toString()).append("|") 
    				.append(sh.getShipmentStatus().toString()).append("|") 
    				.append(sh.getCarrierId().toString() + "\n");
    	}
        
    }
    
    public StringBuilder getShipmentDetails() {
        return shipmentDetails;
    }
    

}

