package pkgOOPSLC7;


public class CustomerShipment extends ShipmentEntity{
	private Double referalFee;

	
	/*public CustomerShipment(String name, Double weight, Integer quantity, Double transferCost,
			Double maxShipmentCapacity, Double referalFee) {
		//fill the code
	}*/
	
	

	public CustomerShipment(String name, Double weight, Integer quantity,
			Double transferCost, Double maxShipmentCapacity, Double referalFee) {
		super(name, weight, quantity, transferCost, maxShipmentCapacity);
		this.referalFee = referalFee;
	}



	public Double getReferalFee() {
		return referalFee;
	}

	public void setReferalFee(Double referalFee) {
		this.referalFee = referalFee;
	}

	public void calculateCost(){
		//fill the code
		//this method is to compute tax for the corresponding cost and display it.
		double cost = (getWeight()*getQuantity()*getTransferCost()) + getReferalFee();
		System.out.println("Cost for the shipment is " + cost);
	}
	
	public void operatingCapacity(){
		//fill the code
		//this method is to check  whether the shipment is within the maximum shipment capacity of company.
		if((getTransferCost() + getReferalFee()) < getMaxShipmentCapacity())
		{
			System.out.println("The shipment is within the shipping capacity of the agent");
		}
		else
		{
			System.out.println("The shipment is not within the shipping capacity of the agent");
		}
	}
}
