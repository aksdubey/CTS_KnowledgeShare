package pkgOOPSLC6;


public class Ferry extends WaterCarrier{
	Integer maxLoad;

	public Ferry(){
		
	}
	
	public Ferry(String carrierName, String carrierCode, String iataCode, 
			String carrierAddress, String carrierType,
			Integer maxLoad) {
		super(carrierName, carrierCode, iataCode, carrierAddress, carrierType);
		this.maxLoad = maxLoad;
	}

	public Integer getMaxLoad() {
		return maxLoad;
	}

	public void setMaxLoad(Integer maxLoad) {
		this.maxLoad = maxLoad;
	}

	@Override
	public void displayShipDetails() {
		// TODO Auto-generated method stub
		/*System.out.format("%-20s%-15s%-15s%-15s%-15s%-25s%s\n",
				"Carrier type","Name","Code","IATAcode","Location","Capacity","OwnedBy");*/
		System.out.format("%-20s%-15s%-15s%-15s%-15s%-25s%-20s\n",
				getCarrierType(),getCarrierName(),getCarrierCode(),getIataCode(),
				getCarrierAddress(),getMaxLoad() + " kilograms","Agent");
		
	}

	//fill the code
}
