package pkgOOPSLC6;

public class BulkShip extends WaterCarrier{
	Integer noOfcargoes;

	public BulkShip(){
		
	}
	
	public BulkShip(String carrierName, String carrierCode, String iataCode, String carrierAddress, String carrierType,
			Integer noOfcargoes) {
		super(carrierName, carrierCode, iataCode, carrierAddress, carrierType);
		this.noOfcargoes = noOfcargoes;
	}

	public Integer getNoOfcargoes() {
		return noOfcargoes;
	}

	public void setNoOfcargoes(Integer noOfcargoes) {
		this.noOfcargoes = noOfcargoes;
	}

	@Override
	public void displayShipDetails() {
		// TODO Auto-generated method stub
		/*System.out.format("%-20s%-15s%-15s%-15s%-15s%-25s%s\n",
		"Carrier type","Name","Code","IATAcode","Location","Capacity","OwnedBy");*/
		System.out.format("%-20s%-15s%-15s%-15s%-15s%-25s%s\n",
			getCarrierType(),getCarrierName(),getCarrierCode(),getIataCode(),
			getCarrierAddress(),getNoOfcargoes() + " cargoes","Company");
		
	}

	//fill the code
}

