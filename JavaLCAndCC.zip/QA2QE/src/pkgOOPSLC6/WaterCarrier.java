package pkgOOPSLC6;


public abstract class WaterCarrier {
	protected String carrierName;
	protected String carrierCode;
	protected String carrierType;
	protected String iataCode;
	protected String carrierAddress;
	
	public WaterCarrier(){
		
	}
	
	public WaterCarrier(String carrierName, String carrierCode, String iataCode, String carrierAddress,String carrierType) {
		super();
		this.carrierName = carrierName;
		this.carrierCode = carrierCode;
		this.iataCode = iataCode;
		this.carrierAddress = carrierAddress;
		this.carrierType = carrierType;
	}
	
	public abstract void displayShipDetails();
	
	public static WaterCarrier createShip(String carrierName, String carrierCode, 
			String iataCode, String carrierAddress,String carrierType,Integer capacity)
	{
		
		//to create and return the water carrier objects.
		if(carrierType.equalsIgnoreCase("BulkShip"))
		{
			return new BulkShip(carrierName, carrierCode, 
					iataCode, carrierAddress, carrierType, capacity);
		}
		else if(carrierType.equalsIgnoreCase("ContainerShip"))
		{
			return new ContainerShip(carrierName, carrierCode, 
					iataCode, carrierAddress, carrierType, capacity);
		}
		else if(carrierType.equalsIgnoreCase("Ferry") || carrierType.equalsIgnoreCase("Ferries"))
		{
			return new Ferry(carrierName, carrierCode, 
					iataCode, carrierAddress, carrierType, capacity);
		}
		return null;
	}

	public static String returnOwner(WaterCarrier waterCarrier)
	{
		//to return the owner of the ship(either company or agent).
		String ret = null;
		switch (waterCarrier.getCarrierType()) {
		case "BulkShip":
			ret = "Company";
			break;
		case "ContainerShip":
			ret = "Company";
			break;
		case "Ferry":
			ret = "Agent";
			break;
		default:
			break;
		}
		
		return ret;
	}
	
	public String getCarrierType() {
		return carrierType;
	}

	public void setCarrierType(String carrierType) {
		this.carrierType = carrierType;
	}

	public String getCarrierAddress() {
		return carrierAddress;
	}

	public void setCarrierAddress(String carrierAddress) {
		this.carrierAddress = carrierAddress;
	}

	public String getCarrierName() {
		return carrierName;
	}

	public void setCarrierName(String carrierName) {
		this.carrierName = carrierName;
	}

	public String getCarrierCode() {
		return carrierCode;
	}

	public void setCarrierCode(String carrierCode) {
		this.carrierCode = carrierCode;
	}

	public String getIataCode() {
		return iataCode;
	}

	public void setIataCode(String iataCode) {
		this.iataCode = iataCode;
	}
	
	//fill the code
}
