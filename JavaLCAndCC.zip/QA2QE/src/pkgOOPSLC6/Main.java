package pkgOOPSLC6;

import java.io.*;
import java.util.Scanner;
public class Main {
	public static void main(String args[])throws IOException{
		//fill the code
		String[] Details = null;
		System.out.println("Enter the number of carriers :");
		Scanner in = new Scanner(System.in);
		int No = Integer.parseInt(in.nextLine());
		WaterCarrier waterCarrier[] = new WaterCarrier[No];
		for(int i=0; i<No; i++)
		{
			System.out.println("Enter the carrier " + (i+1) + " details :");
			Details = in.nextLine().split(",");
			
			waterCarrier[i] = WaterCarrier.createShip(Details[0], Details[1], 
					Details[2], Details[3], Details[4], Integer.parseInt(Details[5]));
		}		

		System.out.println("Ship details are");
		System.out.format("%-20s%-15s%-15s%-15s%-15s%-25s%s\n",
				"Carrier type","Name","Code","IATAcode","Location","Capacity","OwnedBy");
		//fill the code
		for(int i=0; i<No; i++)
		{
			waterCarrier[i].displayShipDetails();
		}
		
		in.close();
		
	}
}
