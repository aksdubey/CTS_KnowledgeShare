package pkgJDBCLC2;

import java.sql.SQLException;
import java.util.ArrayList;



public class Main {

    public static void main(String[] args) throws InstantiationException, 
    IllegalAccessException, ClassNotFoundException, SQLException {
        
         //fill your code
    	
    	System.out.format("%-10s %-20s %-25s %-10s %-10s \n","User","Role","Street","City","State");
    	UserDAO ud = new UserDAO();
    	ArrayList<User> list = ud.getAllUsers();
    	
    	for(User u: list)
    	{
    		System.out.format("%-10s %-20s %-25s %-10s %-10s \n",u.getName(),u.getRole().getName()
    				,u.getContact().getStreet(),u.getContact().getCity(),u.getContact().getState());
    	}
    }
}

