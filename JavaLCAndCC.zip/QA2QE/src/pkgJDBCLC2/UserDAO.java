package pkgJDBCLC2;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;



public class UserDAO {

    public ArrayList<User> getAllUsers() throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException {

        //fill your code
    	/*
    	 * This method is used to fetch all the user details from user 
    	 * table and display the user details with their contact and role 
    	 * info  in ascending sorted order based on user name
    	 */
    	
    	Connection con = DbConnection.getConnection();
		Statement stmt=con.createStatement();
		PreparedStatement contactPStmt = null, rolePStmt = null;
		String userQuery = "select * from user order by name";
		String contactQuery = "select * from contact where id = ?";
		String roleQuery = "select * from role where id = ?";
		
		contactPStmt = con.prepareStatement(contactQuery);
		rolePStmt = con.prepareStatement(roleQuery);
		/*String query = "select u.id, u.name, r.id, r.name, c.id, c.street, "
				+ "c.city, c.state from user u inner join role r on u.role_id = r.id "
				+ "inner join contact c on u.contact_id = c.id order by u.name";*/
		ResultSet rs=stmt.executeQuery(userQuery);
		ResultSet rsContact = null;
		ResultSet rsRole = null;
		
		int contactId, roleId;
		ArrayList<User> list = new ArrayList<User>();
		while(rs.next())
		{
			contactId = rs.getInt(3);
			roleId = rs.getInt(4);
			contactPStmt.setInt(1, contactId);
			rsContact = contactPStmt.executeQuery();
			rsContact.next();
			
			rolePStmt.setInt(1, roleId);
			rsRole = rolePStmt.executeQuery();
			rsRole.next();
			
			list.add(new User(rs.getInt(1), rs.getString(2), 
					new Role(rsRole.getInt(1), rsRole.getString(2)), 
					new Contact(rsContact.getInt(1), rsContact.getString(2), 
							rsContact.getString(3), rsContact.getString(4))));
		}
		
		stmt.close();
		contactPStmt.close();
		rolePStmt.close();
		rs.close();
		rsContact.close();
		rsRole.close();
		con.close();  
			
			return list;
    }

}

