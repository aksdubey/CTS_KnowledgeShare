package pkgJDBCLC3;


import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


public class RoleDAO {

    public void createRole(Role roleIns, ArrayList<Privilege> privilegeList) throws SQLException, ClassNotFoundException {

    	//fill the code
    	/*
    	 * This method is used to create a new role in the database and assign the privileges to roles
 in the database.

    	 */
    	Connection con = DbConnection.getConnection();
		Statement stmt=con.createStatement();  
		stmt.executeUpdate("insert into role(name) values('" + roleIns.getName() + "')");
		ResultSet rs = stmt.executeQuery("select id from role where name= '" + roleIns.getName() + "'");
		rs.next();
		int roleId = rs.getInt(1);
		int privilegeId;
		
		for(Privilege p: privilegeList)
		{
			rs = stmt.executeQuery("select id from privilege where name= '" + p.getName() + "'");
			rs.next();
			privilegeId = rs.getInt(1);
			
			stmt.executeUpdate("insert into role_privilege(role_id, privilege_id) "
					+ "values(" + roleId + ", " + privilegeId + ")");
		}
		
		
		stmt.close();
		rs.close();
		con.close();  

    }
    
    public List<Privilege> getPreviligeByRole(String role) throws ClassNotFoundException, SQLException {

    	//fill the code
    	/*
    	 * This method is used to fetch the privileges for the specified role and display them.
    	 */
    	List<Privilege> list = new ArrayList<Privilege>();
    	Connection con = DbConnection.getConnection();
		Statement stmt=con.createStatement();
    	String query = "select p.id, p.name from privilege p inner join role_privilege rp "
    			+ "on p.id = rp.privilege_id inner join role r on "
    			+ "rp.role_id = r.id where r.name = '" + role + "'";
    	ResultSet rs = stmt.executeQuery(query);
    	while(rs.next())
		{
			list.add(new Privilege(rs.getInt(1), rs.getString(2)));
		}

    	
    	stmt.close();
    	rs.close();
    	con.close();
    	
    	return list;
    }

}
