package pkgJDBCLC3;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


public class PrivilegeDAO {
	
	public List<Privilege> getAllPrivileges() throws SQLException, ClassNotFoundException {

		//fill the code
		/*
		 * This method is used to fetch all the privileges from the database and return a list of privileges
		 */
		
		List<Privilege> list = new ArrayList<Privilege>();
		Connection con = DbConnection.getConnection();
		Statement stmt=con.createStatement();  
		ResultSet rs=stmt.executeQuery("select * from privilege");
		
		while(rs.next())
		{
			list.add(new Privilege(rs.getInt(1), rs.getString(2)));
		}
		rs.close();
		stmt.close();
		con.close();  
			
			return list;

	}
	
}
