package pkgJDBCLC3;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
public class Main {
    public static void main(String[] args) throws NumberFormatException, IOException, ClassNotFoundException, SQLException {
        
    	RoleDAO roleDAO = new RoleDAO();
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        
        String[] details = null;
        
        PrivilegeDAO privilegeDAO = new PrivilegeDAO();
        List<Privilege> privileges = privilegeDAO.getAllPrivileges();
        System.out.println("List of privileges :");
        System.out.format("%-15s %s\n","Privilege ID","Privilege Name");
        for(int i=0;i<privileges.size();i++) {
        	System.out.format("%-15s %s\n",privileges.get(i).getId(),privileges.get(i).getName());
        }
        
        System.out.println("Enter number of new Roles to be created :");
        Integer n = Integer.parseInt(br.readLine());
        
        System.out.println("Enter the role and privileges :");
        ArrayList<Privilege> listEachRolePriv = new ArrayList<Privilege>();
        for(int i=0; i<n; i++)
        {
        	listEachRolePriv.clear();
        	details =br.readLine().split(",");
        	for(int j=1;j<details.length; j++)
        	{
        		listEachRolePriv.add(new Privilege(details[j]));
        	}
        	
        	roleDAO.createRole(new Role(details[0]), listEachRolePriv);
        }

        //fill the code
        
        System.out.println("Enter the Role :");
        String rol = br.readLine();
        System.out.println("Privileges for "+rol+" :");

        //fill the code
        List<Privilege> priv = roleDAO.getPreviligeByRole(rol);
        for(Privilege p: priv)
        {
        	System.out.println(p.getName());
        }

    }
}

