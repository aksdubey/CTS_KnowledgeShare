package pkgCollectionsLC6;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;


public class Main {
	
	public static void main(String args[]) throws IOException{
	    //fill your code 
	    	BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	 	   //fill your code
	 	 	int No, mark, iCnt1 = 0, iCnt2= 0, iCnt3= 0, iCnt4= 0;
	 	 	String name;
	 	 	Map<String, Integer> map= new HashMap<String, Integer>();
	 	 	System.out.println("Enter the number of students");
 	 		No = Integer.parseInt(br.readLine());
 	 		
 	 		for(int i=0; i<No; i++)
 	 		{
 	 			System.out.println("Enter the name of student " + (i+1));
 	 			name = br.readLine();
 	 			System.out.println("Enter the mark of student " + (i+1));
 	 			mark = Integer.parseInt(br.readLine());
 	 			map.put(name, mark); 	 			
 	 		}
 	 		
 	 		for(Entry<String, Integer> eachMap: map.entrySet())
 	 		{
 	 			mark = eachMap.getValue();
 	 			if(mark > 0 && mark <=50)
 	 			{
 	 				iCnt1++;
 	 			}
 	 			else if(mark > 50 && mark <=70)
 	 			{
 	 				iCnt2++;
 	 			}
 	 			else if(mark > 70 && mark <=90)
 	 			{
 	 				iCnt3++;
 	 			}
 	 			else if(mark > 90 && mark <100)
 	 			{
 	 				iCnt4++;
 	 			}
 	 		}
 	 		
 	 		System.out.println("0-50 : " + iCnt1);
 	 		System.out.println("50-70 : " + iCnt2);
 	 		System.out.println("70-90 : " + iCnt3);
 	 		System.out.println("90-100 : " + iCnt4);
	}

}
