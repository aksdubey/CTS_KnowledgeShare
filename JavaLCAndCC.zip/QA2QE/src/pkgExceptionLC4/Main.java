package pkgExceptionLC4;

import java.util.Scanner;
public class Main {
	public static void main(String args[]){
			// fill code here
		String[] Details = null;		
		Scanner in = new Scanner(System.in);
		System.out.println("Enter the container number :");
		String containerNumber = in.nextLine();
		System.out.println("Enter the capacity of container :");
		float containerWeight = Float.parseFloat(in.nextLine());
		System.out.println("Enter the number of commodities :");
		int No = Integer.parseInt(in.nextLine());
		Commodity[] commodity = new Commodity[No];
		Container container = new Container(containerNumber, containerWeight, commodity);
		ShipmentBO sbo = new ShipmentBO();
		System.out.println("Enter the commodities :");
		for(int i=0; i<No; i++)
		{			
			Details = in.nextLine().split(",");
			commodity[i] = new Commodity(Details[0], Float.parseFloat(Details[1]), Integer.parseInt(Details[2]));
		}
		
		try{
			sbo.validate(container, commodity);
		}
		catch(ContainerOverloadedException cex)
		{
			System.out.println("ContainerOverloadedException: Container is overloaded ");
		}
		
		in.close();
	}
}

