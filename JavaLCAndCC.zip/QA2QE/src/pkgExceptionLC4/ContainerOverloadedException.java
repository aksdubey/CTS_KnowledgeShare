package pkgExceptionLC4;

public class ContainerOverloadedException extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	ContainerOverloadedException(String str)
	{
		super(str);
	}

}
