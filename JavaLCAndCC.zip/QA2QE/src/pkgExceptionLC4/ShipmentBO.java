package pkgExceptionLC4;

import java.text.DecimalFormat;

public class ShipmentBO {
	
	
	void validate(Container container, Commodity[] commodity) throws ContainerOverloadedException
	{
		
		DecimalFormat dm = new DecimalFormat("##.##");
	
		/*
		 * To check whether the weight of all the commodities is less than capacity of the container. 
		 * If it satisfies the above condition display the commodity details or 
		 * else throw ContainerOverloadedException.
		 */
		float sum = 0;
		for(int i=0; i<commodity.length; i++)
		{
			sum = sum + commodity[i].getTotalWeight();
		}
		if(sum <= container.getContainerWeight())
		{
			//satisfies condition
			System.out.println("Commodity details are");
			System.out.format("%-15s%-15s%s\n", "Id","Weight","Quantity");
			for(int i=0; i<commodity.length; i++)
			{
				System.out.format("%-15s%-15s%s\n", commodity[i].getCommodityId(),
						dm.format(commodity[i].getTotalWeight())
						,commodity[i].getQuantity());
			}
		}
		else
		{
			throw new ContainerOverloadedException("Container is overloaded");
		}
	}
}

