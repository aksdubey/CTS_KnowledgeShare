package pkgWriterLC1;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Main {

	
public static void main(String args[]) throws NumberFormatException, IOException{

 	   	//fill your code
		BufferedReader in = new BufferedReader(new FileReader("input.txt"));
		List<User> list = new ArrayList<User>();
		String str;
	    while ((str = in.readLine()) != null)
	    {
	    	list.add(new User(Long.parseLong(str.substring(0, 5)), 	    			
	    			str.substring(5, 15), 
	    			str.substring(15, 25), 
	    			str.substring(25, 35), 
	    			str.substring(35, 43),
	    			str.substring(43, 53)));
	    }
	    in.close();
 		
	    System.out.format("%-10s %-15s %-15s %-15s %-15s %s\n", 
	 			   "id", "First Name", "Last Name", "Username", "Password", "Mobile Number");
	    for(User eachUser: list)
	    {
	    	System.out.println(eachUser.toString());
	    }
	    
	}
}
