package pkgCollectionsLC4;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;



class Main{  
	public static void main(String args[]) throws IOException{  
	  //fill your code  
		//int No = 0;
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	   //fill your code
	 	List<Port> list = new ArrayList<Port>();
	 	String[] details = null;
	 	String choice;
	 	System.out.println("Enter the port details");
	 	do{
	 		//No++;
		 	details = br.readLine().split(",");
	 		list.add(new Port(Integer.parseInt(details[0]), details[1], details[2]));
	 		System.out.println("Do you want to continue[Yes/No]");
	 		choice = br.readLine(); 
	 	}
	 	while(choice.equals("Yes"));
	 	 	
		//Sort
	 	Port temp;
	 	Port oPort1;
	 	Port oPort2;
	 	for(int i=0; i<list.size(); i++)
	 	{
	 		for(int j=1; j<(list.size()-i); j++)
	 		{  
	 			oPort1 = list.get(j-1);
	 			oPort2 = list.get(j);
		 		if(oPort1.compareTo(oPort2) > 0)
		 		{
		 			temp = oPort1;  
		 			list.set(j-1, list.get(j));  
                    list.set(j, temp);  
		 		}
	 		}
	 	}
	 	
	 	System.out.println("Port details in sorted order");
	 	System.out.format("%-15s %-15s %-15s","Port Id","Name","Country");
	 	System.out.println();
	 	for(int i=0; i<list.size(); i++)
	 	{
	 		System.out.println(list.get(i).toString());
	 	}
	}
 
}
