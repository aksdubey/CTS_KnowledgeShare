package pkgOOPSCC1;

import java.io.*;
public class Main {
	public static void main(String args[])throws IOException{
		BufferedReader buf = new BufferedReader(new InputStreamReader(System.in));
		Directory defaultDirectory = new Directory(null,0000,0000,0000,"Main");
		Directory currentDirectory = defaultDirectory;
		StringBuffer fullPath = new StringBuffer();
		int index = 0;
		Entry[] entry = new Entry[50];
		while(true){
			System.out.println("Available commands :");
			System.out.println("1. list\n2. mkdir\n3. mkfile\n4. path\n5. cd\n6. quit");
			System.out.println("Enter your choice :");
			int command = Integer.parseInt(buf.readLine());
			if(command == 1){
				if(entry[0] == null){
					System.out.println("No directories or files available");
				}
				else{
					for(int i=0;i<index;i++){
						System.out.println(entry[i].getName());
					}
				}
			}else if(command == 2){
				System.out.println("Enter the directory details :");
				String directory = buf.readLine();
				String directoryDetails[] = directory.split(",");
				entry[index++] = new Directory(currentDirectory, Long.parseLong(directoryDetails[1]),Long.parseLong(directoryDetails[2]), Long.parseLong(directoryDetails[3]),directoryDetails[0]);
			}else if(command == 3){
				System.out.println("Enter the file details :");
				String file = buf.readLine();
				String fileDetails[] = file.split(",");
				entry[index++] = new File(currentDirectory, Long.parseLong(fileDetails[1]), Long.parseLong(fileDetails[2]), Long.parseLong(fileDetails[3]),fileDetails[0]);
			}else if(command == 4){
				int i,flag=0;
				System.out.println("Enter the file or directory to find path :");
				String fileOrDirectory = buf.readLine();
				if(entry[0] == null){
					System.out.println("File or directory not found");
				}
				else{
					for(i=0;i<index;i++){
						if(entry[i].getName().equals(fileOrDirectory)){
							flag = 1;
							break;
						}
					}
					if(flag==1){
						String[] path =  entry[i].getFullPath(fullPath).toString().split("/");
						for(int j = path.length-1;j>=0;j--){
							System.out.print(path[j] + "/");
						}
						System.out.println();
					}
					else{
						System.out.println("File or directory not found");
					}
				}
			}else if(command == 5){
				int flag=0,i;
				System.out.println("Enter the directory name :");
				String cd = buf.readLine();
				if(entry[0] == null){
					System.out.println("No such directory");
				}
				else{
					for(i=0;i<index;i++){
						if(entry[i].getName().equals(cd)){
							flag = 1;
							break;
						}
					}
					if(flag == 1)
						currentDirectory = (Directory) entry[i];
					else{
						System.out.println("No such directory");
					}
				}
			}else
				break;
		}
	}
}
