package pkgOOPSCC1;
public class File extends Entry{

	public File(Directory parent, long created, long lastUpdated, long lastAccessed, String name) {
		super(parent, created, lastUpdated, lastAccessed, name);
	}
}
