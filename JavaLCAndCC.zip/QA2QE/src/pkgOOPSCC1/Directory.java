package pkgOOPSCC1;
public class Directory extends Entry{

	public Directory(Directory parent, long created, long lastUpdated, long lastAccessed, String name) {
		super(parent, created, lastUpdated, lastAccessed, name);
	}
}
