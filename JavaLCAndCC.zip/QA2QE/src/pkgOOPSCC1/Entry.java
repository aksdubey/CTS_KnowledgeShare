package pkgOOPSCC1;
public abstract class Entry {
        protected Directory parent;
        protected Long created;
        protected Long lastUpdated;
        protected Long lastAccessed;
        protected String name;
        
		
        public Entry(Directory parent, long created, long lastUpdated, long lastAccessed, String name) {
			super();
			this.parent = parent;
			this.created = created;
			this.lastUpdated = lastUpdated;
			this.lastAccessed = lastAccessed;
			this.name = name;
		}

		public Directory getParent() {
			return parent;
		}

		public void setParent(Directory parent) {
			this.parent = parent;
		}

		public long getCreated() {
			return created;
		}

		public void setCreated(long created) {
			this.created = created;
		}

		public long getLastUpdated() {
			return lastUpdated;
		}

		public void setLastUpdated(long lastUpdated) {
			this.lastUpdated = lastUpdated;
		}

		public long getLastAccessed() {
			return lastAccessed;
		}

		public void setLastAccessed(long lastAccessed) {
			this.lastAccessed = lastAccessed;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}
		
		public StringBuffer getFullPath(StringBuffer path){
			
			System.out.println(getParent().getFullPath(path));
			System.out.println(parent.getParent().getName());
			System.out.println(parent.getParent().getParent().getName());
			return path;
			
			
		   //fill the code	
		}
}
