package pkgCollectionsLC1;

import java.io.*;
import java.util.*;
public class Main {
  public static void main(String args[])throws IOException{
		
		// fill your code
	  String temp;
	  List<Commodity> list = new ArrayList<Commodity>(); 
	  String[] details = null;
	  Scanner in = new Scanner(System.in);
	  System.out.println("Enter the number of commodities:");
	  int No = Integer.parseInt(in.nextLine());
	  System.out.println("Enter the commodity details");
	  for(int i=0; i<No; i++)
	  {
		  details = in.nextLine().split(",");
		  if(details[4].equalsIgnoreCase("False"))
		  {
			  temp = "No";
		  }
		  else
		  {
			  temp = "Yes";
		  }
		  list.add(new Commodity(details[0], details[1], details[2], details[3], temp));
	  }
	  
	  System.out.println("Commodity details are:");
	  System.out.format("%-15s%-15s%-15s%-15s%s", "Commodity Name", "Quantity", "Total Value"
				, "TotalWeight", "Hazardous");
	  System.out.println();	  
	  for(int i=0; i<No; i++)
	  {
		  System.out.println(list.get(i).toString());
	  }
	  
	  in.close();
	  
	}
}

