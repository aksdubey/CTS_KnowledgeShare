package pkgExceptionLC3;

public class ShipmentBO {
	public String Validate(String p1,String p2,Port[] ports) throws InvalidPortException {

		//System.out.format("%-15s%-15s%-15s%-15s\n", "Shipment id","Shipment name","Arrival place","Departure place");
		return null;
		//fill the code		
		
	}
	
	Boolean validateShipment(String s1,String s2,Port[] p)
	{
		if(s1.equals(s2))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	void displayShipmentDetails(Shipment shipmentObj,Port[] ports,String p1,String p2)
	{
		if(validateShipment(p1, p2, ports))
		{
			throw new InvalidPortException("Invalid Port");
		}
		else
		{
			String arrivalcountry = null, departurecountry = null;
			System.out.println("Shipment Details :");
			System.out.format("%-15s%-15s%-15s%-15s\n", "Shipment id","Shipment name","Arrival place",
					"Departure place");
			for(int i=0; i<ports.length; i++)
			{
			   if(ports[i].getName().equalsIgnoreCase(p1))
			   {
				   arrivalcountry = ports[i].getCountry();
			   }
			   else if(ports[i].getName().equalsIgnoreCase(p2))
			   {
				   departurecountry = ports[i].getCountry();
			   }
			}
			System.out.format("%-15s%-15s%-15s%-15s\n", shipmentObj.getId(),shipmentObj.getName(),
					p1 + "/" + arrivalcountry, p2 + "/" + departurecountry);
		}
	}
}
