package pkgExceptionLC3;

public class InvalidPortException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	InvalidPortException(String string)
	{
		super(string);
	}
}
