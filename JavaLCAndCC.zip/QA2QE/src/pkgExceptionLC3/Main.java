package pkgExceptionLC3;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {
   public static void main(String args[])throws IOException, InvalidPortException{
	   
	   ShipmentBO sbo = new ShipmentBO();
	   BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	   Port[] port = new Port[4];
	   port[0]=new Port(1,"India","Chennai");
		port[1]=new Port(2,"America","California");
		port[2]=new Port(3,"England","London");
		port[3]=new Port(4,"Australia","Melbourne");
	   Shipment shipment=new Shipment();
	   
	   System.out.println("Enter the Shipment Id ");
	   shipment.setId(Integer.parseInt(br.readLine()));
	   System.out.println("Enter the Shipment Name ");
	   shipment.setName(br.readLine());
	   System.out.println("Available ports are");
	   System.out.format("%-15s %-15s %s","ID","Country","PortName");
	   for(int i=0;i<port.length;i++)
	   {
		   System.out.format("\n%-15s %-15s %s",port[i].getId(),port[i].getCountry(),port[i].getName());
	   }
	   //fill the code
	   System.out.println("\nEnter the arrival port name");
	   String arrivalport = br.readLine();
	   System.out.println("Enter the departure port name");
	   String departureport = br.readLine();
	   for(int i=0; i<port.length; i++)
	   {
		   if(port[i].getName().equalsIgnoreCase(arrivalport))
		   {
			   shipment.setArrivalport(port[i]);
		   }
		   else if(port[i].getName().equalsIgnoreCase(departureport))
		   {
			   shipment.setDepartureport(port[i]);
		   }
	   }

	   try{
		   sbo.displayShipmentDetails(shipment, port, arrivalport, departureport);
	   }
	   catch(InvalidPortException ix)
	   {
		   System.out.println("InvalidPortException: The port name is invalid");
	   }

	   
   }
}

