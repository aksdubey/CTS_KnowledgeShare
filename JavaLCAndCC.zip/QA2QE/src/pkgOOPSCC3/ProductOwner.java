package pkgOOPSCC3;

import java.io.*;
public class ProductOwner extends User{

    public ProductOwner(String name, String userName, String password, String role) {
        super(name, userName, password, role);
    }
    
    //System.out.format("%-15s %-15s %-15s %s\n", "Id","Description","Budget","Time"). 
    
    /*public Boolean allocateBudget(String budgetDetail,Requirement[] requirement) throws Exception
    {
        int i,size = 0;
         //fill code here.
    }
    
    public Boolean allocatePlanTime(String planTimeDetail,Requirement[]requirement) throws Exception
    {
       int i,size = 0;
         //fill code here.
    }*/
}

