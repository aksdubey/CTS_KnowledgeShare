package pkgOOPSCC3;

import java.io.*;
public class Main {
    
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int n,i,choice;
        String[] userDetail;
        System.out.println("Enter number of user :");
        n = Integer.parseInt(br.readLine());
        User user[] = new User[n];
        
        Requirement[] requirement = new Requirement[20];
        for(i=0;i<n;i++)
        {
            System.out.println("Enter user "+(i+1)+" detail :");
            userDetail = br.readLine().split(",");
			//fill code here.
            user[i] = new User(userDetail[0], userDetail[1], userDetail[2], userDetail[3]);
        }
        while(true)
        {
            System.out.println("1. Login\n2. Exit\nEnter your choice :");
            choice = Integer.parseInt(br.readLine());
            if(choice == 2)
                System.exit(0);
            System.out.println("Enter the user name :");
            String userName = br.readLine();
            System.out.println("Enter the password :");
            String password = br.readLine();
            for(User u : user)
            {
                if(u.getUserName().equals(userName) && u.getPassword().equals(password))
                {
                        u.display(br,requirement,user);   
                }
            }
        }
    }
    
}

