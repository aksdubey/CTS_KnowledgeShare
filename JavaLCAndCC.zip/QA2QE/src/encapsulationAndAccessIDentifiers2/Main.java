package encapsulationAndAccessIDentifiers2;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String shipperName;
		String modeOfTransportation;
		Float totalWeight;
		String arrivalPort;
		String departurePort;
				
		Scanner in = new Scanner(System.in);
		System.out.println("Enter the number of shipments :");
		int No = Integer.parseInt(in.nextLine());
		Shipment[] sh = new Shipment[No];
		for(int i=0; i<No; i++)
		{
			System.out.println("Enter the shipment " + (i+1) + " details");
			System.out.println("Enter the shipper name :");
			shipperName = in.nextLine();
			System.out.println("Enter the mode of transportation :");
			modeOfTransportation = in.nextLine();
			System.out.println("Enter the total weight :");
			totalWeight = Float.parseFloat(in.nextLine());
			System.out.println("Enter the arrival port :");
			arrivalPort = in.nextLine();
			System.out.println("Enter the departure port :");
			departurePort = in.nextLine();
			sh[i] = Shipment.createNewShipment(shipperName, modeOfTransportation, 
					totalWeight, arrivalPort, departurePort);
		}
		
		System.out.println("Shipment details are");
		System.out.println(String.format("%-15s%-15s%-25s%-15s%-20s%s",
				"Id","Shippername","Mode of transportation",
				 "Total weight","Arrival port","Departure port"));
		/*System.out.format("%-15d%-15s%-25s%-15s%-20s%s", "Id", "Shippername", 
				"Mode of transportation", "Total weight", "Arrival port", "Departure port");*/
		for(int i=0; i<No; i++)
		{
			System.out.println(sh[i].toString());
		}		
		
		in.close();
	}

}
