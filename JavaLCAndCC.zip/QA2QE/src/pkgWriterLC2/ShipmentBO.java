package pkgWriterLC2;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ShipmentBO {
	
	public List<Commodity> readCommodity(String fileName) throws NumberFormatException, IOException
	{
		/*
		 * Read all the values from the file and create commodity object. 
		 * Add all the values to the commodity list and return the list

		 */
		String[] details;
		BufferedReader in = new BufferedReader(new FileReader(fileName));
		List<Commodity> list = new ArrayList<Commodity>();
		String str;
	    while ((str = in.readLine()) != null)
	    {
	    	details = str.split(",");
	    	list.add(new Commodity(Long.parseLong(details[0]), Double.parseDouble(details[1])
	    			, Integer.parseInt(details[2]), details[3].equals("1") ? true : false, 
	    					Long.parseLong(details[4])));
	    }
	    in.close();
		return list;
		
	}
	void checkCommodity(List<Commodity> commodityList)
	{
		/*
		 * Read all those commodities and display the total weight and 
		 * total quantities in the console. If there is any hazardous commodity 
		 * then print a message "Hazardous commodity found"

		 */
		Double weight = 0.00;
		int quantity = 0;
		boolean blnHaz = false;
		for(Commodity com: commodityList)
		{
			weight += com.getWeight();
			quantity += com.getQuantity();
			if(com.getHazardous())
			{
				blnHaz = true;
			}
		}
		
		System.out.println("Total Weight: " + weight);
		System.out.println("Total Quantity: " + quantity);
		if(blnHaz)
		{
			System.out.println("Hazardous Commodity Found!");
		}
		
	}

}
