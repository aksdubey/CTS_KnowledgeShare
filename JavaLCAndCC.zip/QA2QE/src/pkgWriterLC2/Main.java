package pkgWriterLC2;

import java.io.IOException;



public class Main {

	
	public static void main(String args[]) throws NumberFormatException, IOException{

 	   	//fill your code
		/*String[] details;
		BufferedReader in = new BufferedReader(new FileReader("input.txt"));
		List<Commodity> list = new ArrayList<Commodity>();
		String str;
	    while ((str = in.readLine()) != null)
	    {
	    	details = str.split(",");
	    	list.add(new Commodity(Long.parseLong(details[0]), Double.parseDouble(details[1])
	    			, Integer.parseInt(details[2]), Boolean.parseBoolean(details[3]), Long.parseLong(details[4])));
	    }
	    in.close();*/
		
		ShipmentBO sbo = new ShipmentBO();
		
		sbo.checkCommodity(sbo.readCommodity("input.txt"));
		
	}
}
