package displayCompanyDetails;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String identifier, iata, fmc, state, country;
		Scanner in = new Scanner(System.in);
		System.out.println("Enter the number of companies :");
		int No = Integer.parseInt(in.nextLine());
		
		
		Company[] company = new Company[No];
		
		for(int i=0; i<No; i++)
		{
			System.out.println("Enter the company " + (i+1) + " details :");
			System.out.println("Enter company id :");
			identifier = in.nextLine();
			System.out.println("Enter the company's IATA code :");
			iata = in.nextLine();
			System.out.println("Enter the company's FMC code :");
			fmc = in.nextLine();
			System.out.println("Enter the company's state :");
			state = in.nextLine();
			System.out.println("Enter the company's country :");
			country = in.nextLine();
			//Address address = new Address(state, country);
			company[i] = new Company(identifier, iata, fmc, new Address(state, country));
		}
		
		CompanyBO companyBO = new CompanyBO();
		companyBO.displayCompanyDetails(company);
		
		
		in.close();
	}

}
