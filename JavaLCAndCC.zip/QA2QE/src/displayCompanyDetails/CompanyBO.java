package displayCompanyDetails;

public class CompanyBO {
	
	boolean blnAllIndia = true;
	public void displayCompanyDetails(Company[] company)
	{
		for(int i=0; i<company.length; i++)
		{
			if(!company[i].getAddress().getCountry().equalsIgnoreCase("India"))
			{
				blnAllIndia = false;
			}			
		}
		
		if(blnAllIndia)
		{
			System.out.println("All companies are inside India");
		}
		else
		{
			System.out.println("Companies outside India :");
			System.out.format("%-15s %-15s %-15s %-15s %s","Company ID","IATA Code","FMC Code","State","Country");
			System.out.println();
			for(int i=0; i<company.length; i++)
			{
				if(!company[i].getAddress().getCountry().equalsIgnoreCase("India"))
				{	
					System.out.format(company[i].toString());
					/*System.out.format("%-15s %-15s %-15s %-15s %s",company[i].getIdentifier()
							,company[i].getIata(),company[i].getFmc()
							,company[i].getAddress().getState(),company[i].getAddress().getCountry());*/
					//System.out.println();
				}
			}
		}
	}

}
