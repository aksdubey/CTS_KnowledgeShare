package pkgCollectionsLC2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;


public class Main {
 public static void main(String args[]) throws IOException{
 
 BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
   //fill your code
 	List<Port> list = new ArrayList<Port>();
 	String[] details = null;
 	System.out.println("Enter the number of port details");
 	int No = Integer.parseInt(br.readLine());
 	System.out.println("Enter the port details");
 	for(int i=0; i<No; i++)
 	{
 		details = br.readLine().split(",");
 		list.add(new Port(Integer.parseInt(details[0]), details[1], details[2]));
 	}
 	//System.out.println();
 	System.out.format("%-15s %-15s %-15s","Port Id","Name","Location");
 	System.out.println();
 	for(int i=0; i<No; i++)
 	{
 		System.out.println(list.get(i).toString());
 	}
 	
 	System.out.println("Enter the position");
 	int pos = Integer.parseInt(br.readLine());
 	System.out.println("Enter port detail to be inserted");
 	details = br.readLine().split(",");
 	Port portToIns = new Port(Integer.parseInt(details[0]), details[1], details[2]);
 	
 	//ArrayList.add
 	list.add(pos-1, portToIns);
 	
 	System.out.println("After the insertion of port details");
 	System.out.format("%-15s %-15s %-15s","Port Id","Name","Location");
 	System.out.println();
 	for(int i=0; i<=No; i++)
 	{
 		System.out.println(list.get(i).toString());
 	}
 }
}

