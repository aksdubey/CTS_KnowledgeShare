package pkgWriterLC3;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.List;



public class UserBO {
	
	public void saveAllUser(List<User> userList,String fileName) throws IOException
	{
		File file = new File(fileName);
		BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file)));
		for(User user: userList)
	    {
			writer.write(user.getId() + "," + user.getFirstName() 
					+ "," + user.getLastName() + "," + user.getUsername() 
					+ "," + user.getPassword() + "," + user.getMobileNumber() 
					+ "," + user.getRole().getRoleId() + "," + user.getRole().getName() + "\n");
	    }
	    System.out.println("User information saved successfully");
	    writer.flush();
		writer.close();
	}

}
