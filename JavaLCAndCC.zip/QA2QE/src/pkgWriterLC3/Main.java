package pkgWriterLC3;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class Main {
	
	public static void main(String args[]) throws NumberFormatException, IOException{

		Role[] roles = new Role[3];
		roles[0] = new Role((long) 100, "Admin");
		roles[1] = new Role((long) 101, "Shipping Manager");
		roles[2] = new Role((long) 102, "Purchase Manager");
		
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		List<User> list = new ArrayList<User>();
 	   //fill your code
		String firstName, lastName, username, password, mobileNumber;
		
 	 	System.out.println("Enter the number of users:");
 		int No = Integer.parseInt(br.readLine());
 		String roleName;
 		System.out.println("Enter the user details:");
 		for(int i=0; i<No; i++)
 		{
 			System.out.println("Enter the User ID");
 			Long id = Long.parseLong(br.readLine());
 			System.out.println("Enter the first name");
 			firstName = br.readLine();
 			System.out.println("Enter the last name");
 			lastName = br.readLine();
 			System.out.println("Enter the username");
 			username = br.readLine();
 			System.out.println("Enter the password");
 			password = br.readLine();
 			System.out.println("Enter the mobile number");
 			mobileNumber = br.readLine();
 			System.out.println("Enter the role name");
 			roleName = br.readLine();
 			for(int j=0; j<roles.length; j++)
 			{
 				if(roles[i].getName().equalsIgnoreCase(roleName))
 				{
 					list.add(new User(id, firstName, lastName, username, password, mobileNumber, roles[i]));
 					break;
 				}
 			}
 		}
 		
 		new UserBO().saveAllUser(list, "output.txt");
	}

}
