package ccPurchaseOrder;

public class PurchaseBO {
	
	public void addNewItem(PurchaseOrder purchaseOrder, Item item, int quantity)
	{
		purchaseOrder.getOrderLineArray()[0].setItem(item);
	}
	
	public void updateItem(OrderLine orderLineObj,int quantity)
	{
		
	}

}
