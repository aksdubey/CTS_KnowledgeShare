package pkgOOPSLC1;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		User userFound = null;
		User userObj = new User(); 
		String[] userDetails = null;
		Scanner in = new Scanner(System.in);
		System.out.println("Enter the total number of users");
		int No = Integer.parseInt(in.nextLine());
		System.out.println("Enter user details");
		User[] user = new User[No];
		for(int i=0; i<No; i++)
		{
			userDetails = in.nextLine().split(",");
			user[i] = new User(userDetails[0], userDetails[1], userDetails[2], userDetails[3]);
		}
		
		System.out.println("1)Search user by user name\n2)Search user by first name and last name\nEnter your option");
		int choice = Integer.parseInt(in.nextLine());
		switch (choice) {
		case 1:
			System.out.println("Enter the user name to search");
			String searchUser = in.nextLine();
			userFound = userObj.findUser(user, searchUser);
			if(userFound == null)
			{
				System.out.println("User not found");
			}
			else
			{
				System.out.println("User details :\nUsername :" 
						+ userFound.getUserName() + "\nFirstName :" + userFound.getFirstName() 
						+ "\nLastName :" + userFound.getLastName() 
						+ "\nContact :" + userFound.getContact());
			}
			break;
		case 2:
			System.out.println("Enter the first name to search");
			String firstName = in.nextLine();
			System.out.println("Enter the last name to search");
			String lastName = in.nextLine();
			userFound = userObj.findUser(user, firstName, lastName);
			if(userFound == null)
			{
				System.out.println("User not found");
			}
			else
			{
				System.out.println("User details :\nUsername :" 
						+ userFound.getUserName() + "\nFirstName :" + userFound.getFirstName() 
						+ "\nLastName :" + userFound.getLastName() 
						+ "\nContact :" + userFound.getContact());
			}
			break;
		default:
			break;
		}
		
		in.close();
		
		
	}

}
