package pkgOOPSLC1;

public class User {

	private String userName;
	private String firstName;
	private String lastName;
	private String contact;
	
	public User()
	{
		
	}
	
	public User(String userName, String firstName, String lastName,
			String contact) {
		super();
		this.userName = userName;
		this.firstName = firstName;
		this.lastName = lastName;
		this.contact = contact;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
	
	User findUser(User userArray[],String userName)
	{
		for(int i=0; i<userArray.length; i++)
		{
			if(userArray[i].getUserName().equalsIgnoreCase(userName))
			{
				return userArray[i];
			}
		}				
		return null;
		
	}
	
	User findUser(User userArray[],String firstName,String lastName)
	{
		for(int i=0; i<userArray.length; i++)
		{
			if(userArray[i].getFirstName().equalsIgnoreCase(firstName) 
					&& userArray[i].getLastName().equalsIgnoreCase(lastName))
			{
				return userArray[i];
			}
		}				
		return null;
		
	}
	
}
