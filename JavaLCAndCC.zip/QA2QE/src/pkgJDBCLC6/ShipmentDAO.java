package pkgJDBCLC6;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


public class ShipmentDAO {
    List<Shipment> getAllShipment() throws SQLException, ClassNotFoundException{
        //fill your code
    	/*
    	 * This method is used to fetch all the details of Shipment from shipment  table and returns the 
    	 * list of  shipment status in ascending order based on id.
    	 */
    	List<Shipment> list = new ArrayList<Shipment>();
    	Connection con = DbConnection.getConnection();
		Statement stmt=con.createStatement();  
		ResultSet rs=stmt.executeQuery("select sh.id, sh.name, sh.arrival_port_name, "
				+ "sh.departure_port_name, sh.cost, sh.shipment_status_id, shStatus.name, "
				+ "shStatus.code from shipment sh inner join shipment_status shStatus "
				+ "on sh.shipment_status_id = shStatus.id");
		
		while(rs.next())
		{
			list.add(new Shipment(rs.getInt(1),rs.getString(2),rs.getString(3), rs.getString(4), rs.getDouble(5),
					new ShipmentStatus(rs.getInt(6), rs.getString(7), rs.getInt(8))));
		}
		
		stmt.close();
		rs.close();
		con.close();
		
		return list;
    }
    List<ShipmentStatus> getAllShipmentStatus() throws SQLException, ClassNotFoundException 
    {
        //fill your code
    	/*
    	 * This method is used to fetch all the details of Shipment status from the shipment 
    	 * status table and returns the list of shipment status in ascending order based on id.
    	 */
    	
    	List<ShipmentStatus> list = new ArrayList<ShipmentStatus>();
    	Connection con = DbConnection.getConnection();
		Statement stmt=con.createStatement();  
		ResultSet rs=stmt.executeQuery("select * from shipment_status order by id");
		
		while(rs.next())
		{
			list.add(new ShipmentStatus(rs.getInt(1),rs.getString(2),rs.getInt(3)));
		}
		
		stmt.close();
		rs.close();
		con.close();
		
		return list;
    }

    void updateShipment(int shipmentId, int shipmentStatusId) throws SQLException, ClassNotFoundException{
       //fill your code
    	/*
    	 * This method is used to update the status ShipmentStatus [which is passed as the second 
    	 * parameter] of the corresponding shipment given by the ShipmentId [ which is passed 
    	 * as the first parameter]. The return type of this method is void.
    	 */
    	String Query = "update shipment set shipment_status_id = shipmentStatusID where id = shipmentID";
    	Connection con = DbConnection.getConnection();
		Statement stmt=con.createStatement();  
		stmt.executeUpdate(Query.
				replace("shipmentStatusID", String.valueOf(shipmentStatusId)).
				replace("shipmentID", String.valueOf(shipmentId)));
		
		
		stmt.close();
		con.close();
    }
}

