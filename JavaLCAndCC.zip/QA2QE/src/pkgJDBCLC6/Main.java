package pkgJDBCLC6;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.List;



public class Main {
  
  public static void main(String ags[])throws Exception{
      BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
           //fill your code
      ShipmentDAO shipmentDAO = new ShipmentDAO();
      System.out.println("List of the Shipment Details");
      System.out.format("%-5s %-20s %-20s %-20s %-10s %s",
    		  "Id", "Name","Arrival PortName","Departure PortName","Cost","Status");
      List<Shipment> list = shipmentDAO.getAllShipment();
      
      for(Shipment sh: list)
      {
    	  System.out.format("\n%-5s %-20s %-20s %-20s %-10s %s",
    			  sh.getId(),sh.getName(),sh.getArrivalPortName(),
    			  sh.getDeparturePortName(),sh.getCost(),sh.getShipmentStatus().getName());
      }
      
      System.out.println("\nSelect the shipment id to be updated");
      int shipmentToBeUpdated = Integer.parseInt(br.readLine());
      System.out.println("Select the id of new shipment status");
      
      List<ShipmentStatus> listShipmentStatus = shipmentDAO.getAllShipmentStatus();
      
      for(ShipmentStatus shStatus: listShipmentStatus)
      {
    	  System.out.println(shStatus.getId() + "." + shStatus.getName());
      }
      
      int NewShipmentStatusID = Integer.parseInt(br.readLine());
      
      System.out.println("List of the updated Shipment Details");
      shipmentDAO.updateShipment(shipmentToBeUpdated, NewShipmentStatusID);

      System.out.format("%-5s %-20s %-20s %-20s %-10s %s",
    		  "Id", "Name","Arrival PortName","Departure PortName","Cost","Status");
      List<Shipment> listUpdated = shipmentDAO.getAllShipment();
      
      for(Shipment sh: listUpdated)
      {
    	  System.out.format("\n%-5s %-20s %-20s %-20s %-10s %s",
    			  sh.getId(),sh.getName(),sh.getArrivalPortName(),
    			  sh.getDeparturePortName(),sh.getCost(),sh.getShipmentStatus().getName());
      }
      
  } 
  
}

