package pkgThreadsLC1;

import java.util.ArrayList;
import java.util.List;

public class ShippingCostThread implements Runnable{
	
	private List<Cargo> cargoList = new ArrayList<Cargo>();
	private List<Double> priceList = new ArrayList<Double>();
	
	public ShippingCostThread(List<Cargo> cargoList) {
		super();
		this.cargoList = cargoList;
	}

	public void run() {
        
       //fill in your code here
		for(Cargo cargo: cargoList)
		{
			if(cargo.getStorageType().equalsIgnoreCase(Cargo.DRY_STORAGE))
			{
				priceList.add(cargo.getWeight() * 0.9);
			}
			else if(cargo.getStorageType().equalsIgnoreCase(Cargo.COLD_STORAGE))
			{
				priceList.add(cargo.getWeight() * 1.85);
			}
		}
        
    }

    public List<Cargo> getCargoList() {
        return cargoList;
    }

    public void setCargoList(List<Cargo> cargoList) {
        this.cargoList = cargoList;
    }


    public List<Double> getPriceList() {
        return priceList;
    }

    public void setPriceList(List<Double> priceList) {
        this.priceList = priceList;
    }
    
}
