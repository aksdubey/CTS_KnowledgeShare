package displayAgentCompany;

import java.io.IOException;

public class AgentBO {
	
	public void displayAgentDetailsByCompany(String name,AgentCompanyFee[] agentCompanyFee) throws IOException
	{
		//displays agent names for a given company
		for(int i=0; i<agentCompanyFee.length; i++)
		{
			if(agentCompanyFee[i] !=null &&
					agentCompanyFee[i].getCompany().getCompanyName().equalsIgnoreCase(name))
			{
				System.out.println(String.format("%-15s %s", agentCompanyFee[i].getAgent().getName(), 
						agentCompanyFee[i].getFees()));
			}
		}
	}
	
	public void displayCompanyDetailsByAgent(String name,AgentCompanyFee[] agentCompanyFee) throws IOException
	{
		//displays the companies for which the given agent works
		for(int i=0; i<agentCompanyFee.length; i++)
		{
			if(agentCompanyFee[i] != null && 
					agentCompanyFee[i].getAgent().getName().equalsIgnoreCase(name))
			{					
				System.out.println(agentCompanyFee[i].getCompany().getCompanyName());
			}
		}
	}

}
