package displayAgentCompany;

import java.io.IOException;
import java.util.Scanner;

public class Main {

	Company[] companies = Main.initCompany();
	public static Company[] initCompany() {
		Company[] companies = new Company[4];
		companies[0] = new Company(1,"FM01","India","Titanic");
		companies[1] = new Company(2,"FM02","America","Arcadia");
		companies[2] = new Company(3,"FM03","England","Umbrella corporation");
		companies[3] = new Company(4,"FM04","France","Omnicorp");
		return companies;
	}
	
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		Main main = new Main();
		
		AgentBO agentBO = new AgentBO();
		Company tempCompany = null;
		String[] tempDetails = null;
		int choiceCo, choiceAgent, fees, choiceFindAgentOrCompanies;
		String AgentDetails,existingAgentName,
		companyFindAgent, agentFindCompany;
		Scanner in = new Scanner(System.in);
		System.out.println("Enter the number of agents :");
		int No = Integer.parseInt(in.nextLine());
		
		
		AgentCompanyFee[] agentCompanyFee = new AgentCompanyFee[No];
		Agent[] agent = new Agent[No];
		
		for(int i=0; i<No; i++)
		{
			System.out.println("Select the company where the agent " + (i+1) + " is going to work :");
			System.out.println("1. Titanic\n2. Arcadia\n3. Umbrella corporation\n4. Omnicorp\nEnter your choice :");
			choiceCo = Integer.parseInt(in.nextLine());
			/*
			 * get company details
			 */
			for(int iCo=0; iCo<4; iCo++)
			{
				//if(initCompany()[iCo].getId() == choiceCo)
				if(main.companies[iCo].getId() == choiceCo)
				{
					tempCompany = initCompany()[iCo];
					break;
				}
			}
			
			System.out.println("1. New Agent\n2. Existing Agent\nEnter the choice :");
			choiceAgent = Integer.parseInt(in.nextLine());
			if(choiceAgent==1)
			{
				System.out.println("Enter the agent details :");
				AgentDetails = in.nextLine();
				tempDetails = AgentDetails.split(",");
				agent[i] = new Agent(tempCompany.getFmcCode(), tempDetails[0], tempDetails[2], tempDetails[1]);
				System.out.println("Enter the fee of the agent :");
				fees = Integer.parseInt(in.nextLine());
				agentCompanyFee[i] = new AgentCompanyFee(fees, agent[i], tempCompany);
			}
			else if(choiceAgent == 2)
			{
				System.out.println("Enter the name :");
				existingAgentName = in.nextLine();
				System.out.println("Enter the fee of the agent :");
				fees = Integer.parseInt(in.nextLine());
				
				//search agent name in Agent class
				for(int j=0;j<agent.length; j++)
				{
					if(agent[j]!= null && 
							agent[j].getName().equalsIgnoreCase(existingAgentName))
					{
						agentCompanyFee[i] = new AgentCompanyFee(fees, agent[j], tempCompany);
						break;
					}
				}
			}
		}
		
		System.out.println("Search:\n1. Find agents\n2. Find companies");
		choiceFindAgentOrCompanies = Integer.parseInt(in.nextLine());
		if(choiceFindAgentOrCompanies == 1)
		{
			System.out.println("Enter the company name :");
			companyFindAgent = in.nextLine();
			System.out.println("Company has");
			agentBO.displayAgentDetailsByCompany(companyFindAgent,agentCompanyFee);
			/*for(int i=0; i<No; i++)
			{
				if(agentCompanyFee[i] !=null &&
						agentCompanyFee[i].getCompany().getCompanyName().equalsIgnoreCase(companyFindAgent))
				{
					System.out.println(String.format("%-15s %s", agentCompanyFee[i].getAgent().getName(), 
							agentCompanyFee[i].getFees()));
				}
			}*/
		}
		else if(choiceFindAgentOrCompanies == 2)
		{
			System.out.println("Enter the agent name :");
			agentFindCompany = in.nextLine();
			System.out.println("Agent works for");
			agentBO.displayCompanyDetailsByAgent(agentFindCompany,agentCompanyFee);	
			/*for(int i=0; i<No; i++)
			{
				if(agentCompanyFee[i] != null && 
						agentCompanyFee[i].getAgent().getName().equalsIgnoreCase(agentFindCompany))
				{					
					System.out.println(agentCompanyFee[i].getCompany().getCompanyName());
				}
			}*/
		}
		
		in.close();
	}

}
