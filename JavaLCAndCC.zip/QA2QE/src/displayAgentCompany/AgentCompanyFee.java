package displayAgentCompany;

public class AgentCompanyFee {
	
	private Agent agent;
	private Company company;
	private Integer fees;
	public AgentCompanyFee(Integer fees, Agent agent, Company company) {
		super();
		this.fees = fees;
		this.agent = agent;
		this.company = company;
	}
	public AgentCompanyFee() {
	}
	public Agent getAgent() {
		return agent;
	}
	public void setAgent(Agent agent) {
		this.agent = agent;
	}
	public Company getCompany() {
		return company;
	}
	public void setCompany(Company company) {
		this.company = company;
	}
	public Integer getFees() {
		return fees;
	}
	public void setFees(Integer fees) {
		this.fees = fees;
	}
	
	
	

}
