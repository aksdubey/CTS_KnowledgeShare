package pkgJDBCLC5;

import java.util.*;
import java.sql.*;

public class CargoDAO {
    
    List<Cargo> filterCargoByWeight(Float weight) throws Exception
    {
        //fill code here.
    	/*
    	 * In this method, filter the cargo details by weight 
    	 * from the database, and it returns the filtered cargo details object.

    	 */
    	
    	List<Cargo> list = new ArrayList<Cargo>();
    	Connection con = DbConnection.getConnection();
		Statement stmt=con.createStatement();  
		ResultSet rs=stmt.executeQuery("select * from cargodetail where weight > " + weight);
		
		while(rs.next())
		{
			list.add(new Cargo(rs.getInt(1),rs.getString(2),rs.getFloat(3), rs.getFloat(4), rs.getFloat(5)));
		}
		
		stmt.close();
		rs.close();
		con.close();
		
		return list;
    }
    
}

