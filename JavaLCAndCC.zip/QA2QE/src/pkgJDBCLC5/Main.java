package pkgJDBCLC5;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
public class Main {

    public static void main(String[] args) throws Exception{
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        List<Cargo> cargoList = new ArrayList<>();
        System.out.println("Enter the weight to filter:");
		//fill code here.
        DecimalFormat sdf = new DecimalFormat("##.00");
        String weight = br.readLine();
        CargoDAO cargoDAO = new CargoDAO();
        cargoList = cargoDAO.filterCargoByWeight(Float.parseFloat(weight));
        
        if(cargoList.size() == 0)
            System.out.println("No cargo found");
        else
        {
            System.out.format("%-15s %-25s %-15s %-15s %s\n", 
            		"Cargo id","Cargo name","Width","Height","Cargo weight");
            //fill code here.
            for(Cargo c: cargoList)
            {
            	System.out.format("%-15s %-25s %-15s %-15s %s\n", 
                		c.getId(),c.getName(),sdf.format(c.getWidth()),sdf.format(c.getHeight()),
                		sdf.format(c.getWeight()));
            }
        }
    }
}

