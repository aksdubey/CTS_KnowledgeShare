package displayPort;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in = new Scanner(System.in);
		System.out.println("Enter the number of ports");
		int No = Integer.parseInt(in.nextLine());
		int id;
		String name, country, decision;
		Port[] port = new Port[No];
		
		for(int i=0; i<No; i++)
		{
			System.out.println("Enter the port" + (i+1) + " details");
			id = Integer.parseInt(in.nextLine());
			name =in.nextLine();
			System.out.println("Is the port from same country[Y/N]");
			decision = in.nextLine();
			if(decision.equals("N"))
			{
				System.out.println("Enter the country");
				country = in.nextLine();
				port[i] = new Port(id, name, country);
			}
			else
			{
				port[i] = new Port(id, name);
			}
		}
		
		System.out.println("The port details are");
		System.out.format("%-15s %-15s %-15s", "Id", "Name", "Country");
		System.out.println();
		
		for(int i=0; i<No; i++)
		{
			System.out.println(port[i].toString());
		}
		
		in.close();

	}

}
